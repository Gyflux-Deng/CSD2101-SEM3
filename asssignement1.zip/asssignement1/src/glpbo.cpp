/*!
@file    glpbo.cpp
@author  Maojie.deng@digipen.edu
@date    6/28/2023
@brief
it is a GLPbo class is used to emulate graphics processing
and perform rendering operations using OpenGL.
The specific details of each member function's
functionality can be found in their respective implementations.

*//*__________________________________________________________________________*/
#include "glpbo.h"
//include the glhelper.h to allow glapp to use the functions written in glhelper
#include <glhelper.h>
//uses math to calculate graphic for linearly interpolating the color components.
#include "math.h"
//uses array library for me to access to array function
#include <array>
//uses iostream library for printing out data
#include <iostream>
//sstream to print out data ontop of the visual studio on top of the windows
#include <sstream>
#include <iomanip>
#include <fstream>
#include "glslshader.h"
#include "string"
#include <dpml.h>
#include <map>

//define 
#define PI 3.14159265358979323846f
//task 1  
/*
* Scan through the definition of type GLPbo and identify static data members. Begin your
* implementation by providing definitions to these static data members in glpbo.cpp .
*/
GLsizei GLPbo::width = 0;
GLsizei GLPbo::height = 0;
GLsizei GLPbo::pixel_cnt = 0; 
GLsizei GLPbo::byte_cnt = 0;
GLuint GLPbo::vaoid = 0;
GLuint GLPbo::elem_cnt = 0;
GLuint GLPbo::pboid = 0;
GLuint GLPbo::texid = 0;
GLPbo::Color* GLPbo::ptr_to_pbo = nullptr;
GLSLShader GLPbo::shdr_pgm{};
GLPbo::Color GLPbo::clear_clr{};
//for my sine graph
GLfloat distanceInterpolated = 0.f;
GLboolean objRotation = false;
//assignment 1
//map to hold data from the obj file meshes
std::map<std::string, GLPbo::Model> GLPbo::meshes;
std::vector<std::string>GLPbo:: meshesData;
std::vector<std::string>::iterator GLPbo::dataIterator;
//changes the mode index
GLint modeIndex = 0;
//data information for data print on bar
int vtxValue = 0;
int triValue = 0;
int cullValue = 0;
//for changing mode
std::vector<std::string> GLPbo::renderName
{
	"Wireframe",
	"Wireframe Color",
	"Facted",
	"Shaded"
};

/*
* @brief this function will be used by our graphics program to emulate the behaviors of vertex
* processor, rasterizer engine in graphics hardware, and fragment processor. This
* function will be called once per frame to write a color for every element in the PBO's
* data store (whose handle is GLPbo::pboid ) and then to transfer the entire data store's
* contents to the texture image storage (whose handle is GLPbo::texid ).
*/
void GLPbo::emulate()
{
	//set the screen color to white only 
	set_clear_color(255, 255, 255, 255);

	//Resetting the values
	vtxValue = 0;
	triValue = 0;
	cullValue = 0;

	//button functions
	buttonPress();
	
	//Part 3
	//Map the PBO data store's address (meaning the address of the data store's first
	//element) to client address space by calling glMapNamedBuffer and assigning the return
	//value to GLPbo::ptr_to_pbo.
	GLPbo::ptr_to_pbo = reinterpret_cast<GLPbo::Color*>(glMapNamedBuffer(GLPbo::pboid, GL_WRITE_ONLY));

	//Part 4
	//Call GLPbo::clear_color_buffer() to fill every pixel in the PBO's data store with the
	//color previously assigned to GLPbo::clear_color in step .
	GLPbo::clear_color_buffer();

	//Part 5
	//After GLPbo::clear_color_buffer() returns, release PBO's pointer in
	//GLPbo::ptr_to_pbo back to the graphics driver by calling glUnmapNamedBuffer .
	glUnmapNamedBuffer(GLPbo::pboid);

	//Part 6
	//Now, initialize the texture image with the PBO's data store by using
	//glTextureSubImage2D to DMA the image in PBO's data store to GLPbo::texid 's
	//texture image store.This is tricky - you'll need to carefully research GL commands
	//glTextureSubImage2D and glBindBuffer .
	//glBindTexture(GL_TEXTURE_2D, GLPbo::texid);
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER, GLPbo::pboid);
	glTextureSubImage2D(GLPbo::texid, 0, 0, 0, GLPbo::width, GLPbo::height, GL_RGBA, GL_UNSIGNED_BYTE, 0);
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
	glBindTexture(GL_TEXTURE_2D, 0);

	std::string selected_model = *dataIterator;

	viewport_xform(meshes[selected_model]);

	size_t meshVtx_list = meshes[selected_model].tris.size();

	//if the list have more than 0 we the rendering
	if (meshVtx_list > 0)
	{
		static size_t counter = meshVtx_list;

		vtxValue = meshes[selected_model].pd.size();
		triValue = meshes[selected_model].tris.size() / 3;

		auto& posVtx_List = meshes[selected_model].posVtx_List;
		auto& mesh_pd = meshes[selected_model].pd;
		auto& mesh_nml = meshes[selected_model].nml;

		for (const Triangle& triangle : posVtx_List)
		{
			// Wireframe rendering
			if (*(meshes[selected_model].mode) == renderName[0])
			{
				if (!wireframe(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], GLPbo::Color{ 0, 0, 0, 0 }))
				{
					++cullValue;
				}
			}

			// Wireframe with color
			else if (*(meshes[selected_model].mode) == renderName[1])
			{
				if (!wireframe(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], triangle.triangleColor))
				{
					++cullValue;
				}
			}

			// Faceted rendering
			else if (*(meshes[selected_model].mode) == renderName[2])
			{
				if (!GLPbo::Triangle::renderTriangle(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], triangle.color[0]))
				{
					++cullValue;
				}
			}

			// Shaded rendering
			else if (*(meshes[selected_model].mode) == renderName[3])
			{
				if (!GLPbo::Triangle::renderTriangleSmooth(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], mesh_nml[triangle.posIndex[0]], mesh_nml[triangle.posIndex[1]], mesh_nml[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
		}
	}

	//rotation
	if (objRotation)
	{
		meshes[selected_model].orientation.x += meshes[selected_model].orientation.y * static_cast<GLfloat>(GLHelper::delta_time);
	}
		

		
}

/**
 * @brief draws a full-window quad using OpenGL.
 * this function sets up the necessary OpenGL state and draws a quad covering the entire window.
 * it binds a texture, selects a shader program, sets uniform values, and calls the necessary OpenGL functions to render the quad.
 * after completing the rendering, it resets the OpenGL state to its original state.
 */
void GLPbo::draw_fullwindow_quad()
{
	//set texture count
	glBindTextureUnit(6, GLPbo::texid);
	////bind texture
	//glBindTextureUnit(GL_TEXTURE_2D, GLPbo::texid);
	// there are many shader programs initialized - here we're saying
	// which specific shader program should be used to render geometry
	GLPbo::shdr_pgm.Use();
	//bind the vao for the whole window
	glBindVertexArray(GLPbo::vaoid);
	//call the shader
	shdr_pgm.SetUniform("Tex2d", 6);
	//draw triangle to form quad
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, NULL);
	//after completing the rendering, we tell the driver that VAO
	//vaoid and current shader program are no longer current
	//also gell texture no longer current too
	glBindVertexArray(0);

	glBindTexture(GL_TEXTURE_2D, 0);
	// after completing the rendering, we tell the driver that VAO
	// vaoid and current shader program are no longer current
	GLPbo::shdr_pgm.UnUse();
	//model name
	std::string modelName = *dataIterator;
	modelName[0] -= ('a' - 'A');
	//u store the string into streamdata
	std::stringstream strData;
	//print out with the percision of setprecision
	strData << std::fixed << std::setprecision(2) << GLHelper::title << " | " << "Maojie Deng"  << 
		" | Model: " << modelName <<" | " 
		<< "Mode: " << *meshes[*dataIterator].mode << " | " 
		<< "Vtx: " << vtxValue << " | " 
		<< "Tri: " << triValue << " | " 
		<< "Culled: " << cullValue << " | " << "FPS: " << GLHelper::fps;
	glfwSetWindowTitle(GLHelper::ptr_window, strData.str().c_str());

}

/**
 * @brief culls back-faces of a triangle using the CCW (Counter Clockwise) convention.
 * @param pos1 The coordinates of the first vertex of the triangle.
 * @param pos2 The coordinates of the second vertex of the triangle.
 * @param pos3 The coordinates of the third vertex of the triangle.
 * @return true if the triangle is not a back-face (CCW), false otherwise.
 */
bool GLPbo::Triangle::CullBackFacesCCW(glm::vec3 pos1, glm::vec3 pos2, glm::vec3 pos3)
{
	//calculate the cross product manually
	float crossProduct = (pos2.x - pos1.x) * (pos3.y - pos1.y) - (pos2.y - pos1.y) * (pos3.x - pos1.x);

	//if the cross product is positive, the triangle is facing towards the camera (CCW)
	//if the cross product is negative, the triangle is facing away from the camera (back-face)
	return crossProduct > 0.f;
}

/**
 * @brief renders a triangle on the screen.
 * @param p0 The coordinates of the first vertex of the triangle.
 * @param p1 The coordinates of the second vertex of the triangle.
 * @param p2 The coordinates of the third vertex of the triangle.
 * @param clr The color of the triangle.
 * @return true if the triangle is rendered successfully.
 */
bool GLPbo::Triangle::renderTriangle(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec3 clr)
{

	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//call your fragment shader or set the pixel color
				set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(clr.r * 255), static_cast<GLubyte>(clr.g * 255), static_cast<GLubyte>(clr.b * 255), 255));
			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;
}

/**
 * @brief renders a smooth shaded triangle on the screen.
 * @param p0 First vertex of the triangle.
 * @param p1 Second vertex of the triangle.
 * @param p2 Third vertex of the triangle.
 * @param clr0 Color at vertex p0.
 * @param clr1 Color at vertex p1.
 * @param clr2 Color at vertex p2.
 * @return true if the triangle was rendered successfully, false otherwise.
 */
bool GLPbo::Triangle::renderTriangleSmooth(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec3 clr0, glm::vec3 clr1, glm::vec3 clr2)
{

	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				glm::vec3 clr{ (((hEval0)*clr0) + ((hEval1)*clr1) + ((hEval2)*clr2)) * surfaceArea };
				set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(clr.x * 255), static_cast<GLubyte>(clr.y * 255), static_cast<GLubyte>(clr.z * 255), 255));
			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;

}

/**
 * @brief applies viewport transformation to the vertices of a model.
 * @param mdl The model whose vertices will be transformed.
 */
void GLPbo::viewport_xform(GLPbo::Model& mdl)
{

	//rotation angle in degrees
	float angle = glm::radians(mdl.orientation.x);

	//create the rotation matrix
	glm::mat4 rotation
	{
		cosf(angle), sinf(angle), 0.0f, 0.0f,
		-sinf(angle), cosf(angle), 0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f
	};

	//create the viewport matrix
	glm::mat4 ndc_to_viewport
	{
		(GLHelper::width / 2.f), 0, 0, 0,
		0, (GLHelper::height / 2.f), 0, 0,
		0, 0, 1, 0,
		(GLHelper::width / 2.f), (GLHelper::height / 2.f), 0, 1
	};

	mdl.pd = mdl.pm;

	//put the model pd into transform
	for (auto& modelVtx : mdl.pd)
	{
		glm::vec4 temp{ modelVtx.x, modelVtx.y,modelVtx.z,1 };
		glm::vec4 calculatedAffine{ ndc_to_viewport * rotation * temp };
		modelVtx = glm::vec3{ calculatedAffine.x, calculatedAffine.y,calculatedAffine.z};
	}
	
}

/**
 * @brief writes the specified color at the given window coordinates in the PBO buffer,
 * taking into account scissoring with the entire window as the scissor rectangle.
 * @param x The x-coordinate of the pixel.
 * @param y The y-coordinate of the pixel.
 * @param clr The color to be written at the pixel.
 */
void GLPbo::set_pixel(GLint x, GLint y, GLPbo::Color clr)
{
	//perform scissoring with the entire window as the scissor rectangle
	if (x < 0 || x >= GLHelper::width || y < 0 || y >= GLHelper::height)
	{
		//pixel is outside the scissor rectangle, skip writing
		return;  
	}

	//calculate the index of the pixel in the PBO buffer
	GLPbo::Color* pixel_ptr = ptr_to_pbo + (GLHelper::width * y) + x;

	//write the color at the pixel location
	*pixel_ptr = clr;
}

/**
 * @brief Handles button press events.
 */
void GLPbo::buttonPress()
{
	//button press for changing object
	if (GLHelper::keystateM)
	{
		//increment the data iterator and wrap around if necessary
		if (++dataIterator == meshesData.end() - 1)
		{
			dataIterator = meshesData.begin();
		}
		GLHelper::keystateM = GL_FALSE;
		objRotation = GL_FALSE;
	}

	//change mode
	if (GLHelper::keystateW)
	{
		//get the selected mesh and increment its mode, wrapping around if necessary
		std::string selected_mesh = *dataIterator;
		if (++meshes[selected_mesh].mode == renderName.end())
		{
			meshes[selected_mesh].mode = renderName.begin();
		}
		GLHelper::keystateW = GL_FALSE;
	}

	//rotate
	if (GLHelper::keystateR)
	{
		//toggle the objRotation flag
		GLHelper::keystateR = GL_FALSE;
		objRotation = (objRotation) ? GL_FALSE : GL_TRUE;
	}
}

/**
 *@brief renders a line using the Bresenham algorithm in the specified octant.
 *This function renders a line segment between two points using the Bresenham algorithm.
 *The algorithm used depends on the value of the bresenham1256 parameter.
 *@param px0 The x-coordinate of the starting point.
 *@param py0 The y-coordinate of the starting point.
 *@param px1 The x-coordinate of the ending point.
 *@param py1 The y-coordinate of the ending point.
 *@param draw_clr The color of the line to be rendered.
*/
void GLPbo::render_linebresenham(GLint px0, GLint py0, GLint px1, GLint py1, GLPbo::Color draw_clr)
{
	////for octian 0 3 4 7
	GLint dx = px1 - px0;
	GLint dy = py1 - py0;

	////determine the step directions for x and y
	int xstep = (dx < 0) ? -1 : 1;
	int ystep = (dy < 0) ? -1 : 1;

	////take absolute values of dx and dy
	dx = (dx < 0) ? -dx : dx;
	dy = (dy < 0) ? -dy : dy;

	////renders a line using Bresenham's line drawing algorithm for octants 1, 2, 5, and 6.
	if (dy < dx)
	{
		//calculate decision variable and error adjustments
		int d = 2 * dy - dx;
		int dmin = 2 * dy;
		int dmaj = 2 * dy - 2 * dx;
		//set the initial pixel
		set_pixel(px0, py0, draw_clr);
		//iterate through the pixels along the line x
		while (--dx)
		{
			//update y coordinate based on decision variable
			py0 += (d > 0) ? ystep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			px0 += xstep;
			//set the pixel
			set_pixel(px0, py0, draw_clr);
		}
	}
	else if (dy > dx)
	{
		//calculate decision variable and error adjustments
		int d = 2 * dx - dy;
		int dmin = 2 * dx;
		int dmaj = 2 * dx - 2 * dy;
		//set the initial pixel
		set_pixel(px0, py0, draw_clr);
		//iterate through the pixels along the line y
		while (--dy)
		{
			//update y coordinate based on decision variable
			px0 += (d > 0) ? xstep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			py0 += ystep;
			//set the pixel
			set_pixel(px0, py0, draw_clr);
		}
	}
	
}

/**
 * @brief draws a wireframe triangle using Bresenham's line algorithm.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param clr The color of the wireframe.
 * @return true if the wireframe was successfully rendered, false otherwise.
 */
bool GLPbo::wireframe(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, GLPbo::Color clr)
{
	//check if back faces should be culled
	if (!GLPbo::Triangle::CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//render lines using Bresenham's line algorithm
	render_linebresenham(static_cast<GLint>(p0.x), static_cast<GLint>(p0.y), static_cast<GLint>(p1.x), static_cast<GLint>(p1.y), clr);
	render_linebresenham(static_cast<GLint>(p1.x), static_cast<GLint>(p1.y), static_cast<GLint>(p2.x), static_cast<GLint>(p2.y), clr);
	render_linebresenham(static_cast<GLint>(p2.x), static_cast<GLint>(p2.y), static_cast<GLint>(p0.x), static_cast<GLint>(p0.y), clr);

	return true;
}

/**
 *@brief checks if a point is in the top-left region defined by an edge equation.
 *@param edge the coefficients of the edge equation in the form of a 3D vector.
 *@param point the coordinates of the point to be checked in the form of a 3D vector.
 *@return true if the point is in the top-left region, false otherwise.
 */
bool GLPbo::Triangle::PointInEdgeTopLeft(float eval, bool tl)
{

	return(eval > 0.f || (eval == 0.f && tl)) ? true : false;
}

/**
 * @brief calculates the coefficients of the edge equation given two points on the edge.
 * @param p1 the coordinates of the first point on the edge.
 * @param p2 tthe coordinates of the second point on the edge.
 * @return the edge equation coefficients as a 3D vector (a, b, c) where ax + by + c = 0.
 */
glm::vec3 GLPbo::Triangle::edgeEquation(glm::vec3 p0, glm::vec3 p1)
{
	//calculate the coefficients of the edge equation
	float pointA = p0.y - p1.y;
	float pointB = p1.x - p0.x;
	float pointC = (p0.x * (p1.y - p0.y)) - (p0.y *(p1.x - p0.x));

	//return the edge equation coefficients as a 3D vector
	return glm::vec3(pointA, pointB, pointC);
}

/**
 * @brief generates a random floating-point number between 0 and 1.
 * @return random float value between 0 and 1.
 */
float GLPbo::rand_float()
{
	return static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
}

/**
 * @brief initializes the GLPbo object with the specified width and height.
 * this function initializes the GLPbo object by setting values for various data members and creating necessary OpenGL objects.
 * it assigns the width and height values to the static data members GLPbo::width and GLPbo::height.
 * it calculates the pixel count and byte count based on the width and height.
 * it sets the PBO fill color and creates a texture object and a PBO using the specified steps.
 * it also sets up the vertex array object and initializes the shader object.
 * @param w The width
 * @param h The height
 */
void GLPbo::init(GLsizei w, GLsizei h)
{
	//assignnment 1
	//read obj file when i init
	GLPbo::init_scene("../scenes/ass-1.scn");

	//Part 3
	/*
	 *Begin by assigning appropriate values to static data members GLPbo::width ,
	 *GLPbo::height , GLPbo::pixel_cnt , and GLPbo::byte_cnt :	
	*/
	width = w;
	height = h;
	//pixel_cnt = width * height
	pixel_cnt = width * height;
	//Data member GLPbo::byte_cnt specifies the size in bytes of the PBO's data store
	//(and texture image) and should therefore be equivalent to pixel_cnt * 4
	byte_cnt = pixel_cnt * 4;
	//Part 4
	//Set the PBO fill color (to white or whatever other color you wish) 
	set_clear_color(255, 255, 255, 255);

	//Part 5
	//Create a texture object with storage for a texture image that is exactly equivalent to the
	//size of the PBO's data store. 
	glCreateTextures(GL_TEXTURE_2D,1, &texid);
	glTextureStorage2D(texid, 1, GL_RGBA8, width, height);
	
	//Part 6
	//Create a PBO using the steps described here.
	glCreateBuffers(1, &pboid);
	glNamedBufferStorage(pboid,byte_cnt,nullptr,GL_DYNAMIC_STORAGE_BIT | GL_MAP_WRITE_BIT);

	//assignment 1 

	//Part 7
	//To render the texture image created from the colors written into the PBO's data store,
	//data member
	setup_quad_vao();
	//Part 8
	//you'll need to initialize the shader object GLPbo::shdr_pgm that will contain the
	//shader program that will render the texture mapped full - screen quad.
	setup_shdrpgm();

}

/**
 * @brief initializes the scene based on the specified scene file.
 * @param scene_filename the filename of the scene file to be loaded.
 */
void GLPbo::init_scene(std::string scene_filename)
{
	std::ifstream ifs(scene_filename, std::ios_base::in | std::ios::binary);
	if (!ifs)
	{
		std::cout << "ERROR: Unable to open image file: " << scene_filename << "\n";
		exit(EXIT_FAILURE);
	}
	const int fileSize = width * height * bytes_per_texel;
	ifs.seekg(0, std::ios::beg);
	char* ptr_texels = new char[fileSize];
	ifs.read(ptr_texels, fileSize);
	ifs.close();
	GLuint texobj_hdl;
	// define and initialize a handle to texture object that will
	// encapsulate two-dimensional textures
	glCreateTextures(GL_TEXTURE_2D, 1, &texobj_hdl);
	// allocate GPU storage for texture image data loaded from file
	glTextureStorage2D(texobj_hdl, 1, GL_RGBA8, width, height);
	// copy image data from client memory to GPU texture buffer memory
	glTextureSubImage2D(texobj_hdl, 0, 0, 0, width, height,
		GL_RGBA, GL_UNSIGNED_BYTE, ptr_texels);
	// client memory not required since image is buffered in GPU memory
	delete[] ptr_texels;
	// nothing more to do - return handle to texture object
	return texobj_hdl;

}

/**
 * @brief sets up the vertex array object (VAO) for rendering a quad in normalized device coordinates (NDC).
 * this function defines the positions and texture coordinates of the vertices that form a quad in the 2D plane.
 * it creates a buffer object to store the vertex data and copies the position and texture coordinate data to the buffer.
 * it then creates a VAO and sets up the vertex attribute state, enabling the necessary vertex attributes,
 * binding them to buffer binding points, and specifying their formats.
 * finally, it defines the indices of the vertices that form the two triangles and attaches the index buffer to the VAO.
 */
void GLPbo::setup_quad_vao()
{
	//we'll define a rectangle in normalizeed device coordinates (NDC)
	// coordinates that has one-fourth the area of the window.
	// The NDC coordinates for a window range from [-1, 1] along both
	// both the X- and Y-axes. Therefore, the rectangle's (x, y) position
	// coordinates are in range [-0.5, 0.5]
	// We're using NDC coordinates, because we don't want to specify
	// a "model-to-world-to-view-to-clip" transform to the vertex shader.

	//define the positions of the 4 vertices of a square in the 2D plane
	std::array<glm::vec2, 4> pos_vtx
	{
		glm::vec2(1.f,-1.f), glm::vec2(1.f, 1.f),
		glm::vec2(-1.f,1.f), glm::vec2(-1.f, -1.f)
	};

	//define the texture coord
	std::array<glm::vec2, 4> texcoord_vtx
	{
		glm::vec2(1.0f, 0.0f), glm::vec2(1.0f, 1.0f),
		glm::vec2(0.0f, 1.0f), glm::vec2(0.0f, 0.0f)
	};

	//create a buffer object to store the vertex data
	GLuint vbo_hdl;
	//allocate storage for the buffer object and specify the usage as dynamic
	glCreateBuffers(1, &vbo_hdl); 
	glNamedBufferStorage(vbo_hdl,sizeof(glm::vec2) * pos_vtx.size() + sizeof(glm::vec2)*texcoord_vtx.size(), nullptr, GL_DYNAMIC_STORAGE_BIT);
	//copy the position data to the buffer object
	glNamedBufferSubData(vbo_hdl, 0, sizeof(glm::vec2) * pos_vtx.size(), pos_vtx.data());
	//copy the texture data to the buffer object data
	glNamedBufferSubData(vbo_hdl, sizeof(glm::vec2) * pos_vtx.size() , sizeof(glm::vec2) * texcoord_vtx.size(), texcoord_vtx.data());

	//get the maximum number of vertex attributes supported by the implementation
	GLint max_vtx_attribs;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &max_vtx_attribs);
	std::cout << "Maximum vertex attributes: " << max_vtx_attribs << '\n';

	GLint max_vtx_binding_buffer;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIB_BINDINGS, &max_vtx_binding_buffer);
	std::cout << "Maximum vertex buffer bindings: " << max_vtx_binding_buffer << '\n';

	//create a vertex array object to store the vertex attribute state
	glCreateVertexArrays(1, &vaoid);

	//enable vertex attribute 8 and bind it to vertex buffer binding point 3
	glEnableVertexArrayAttrib(vaoid, 0);
	glVertexArrayVertexBuffer(vaoid, 3, vbo_hdl, 0, sizeof(glm::vec2));

	//specify the format of the vertex attribute data for attribute 8
	glVertexArrayAttribFormat(vaoid, 0, 2, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 8
	glVertexArrayAttribBinding(vaoid, 0, 3);

	//enable vertex attribute 10 and bind it to vertex buffer binding point 5
	glEnableVertexArrayAttrib(vaoid, 1);
	glVertexArrayVertexBuffer(vaoid, 5, vbo_hdl, sizeof(glm::vec2) * pos_vtx.size(), sizeof(glm::vec2));

	//specify the format of the vertex attribute data for attribute 10
	glVertexArrayAttribFormat(vaoid, 1, 2, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 10
	glVertexArrayAttribBinding(vaoid, 1, 5);

	//define the indices of the vertices that form the two triangles
	std::array<GLushort, 6> idx_vtx
	{
		0, 1, 2,
		2, 3, 0
	};

	GLPbo::elem_cnt = idx_vtx.size();

	//the number of indices in the index array is stored in 'idx_elem_cnt'.
	GLuint ebo_hdl;
	glCreateBuffers(1, &ebo_hdl);

	//generate a buffer object for the index data and store its handle in ebo_hdl.
	glNamedBufferStorage(ebo_hdl, sizeof(GLushort) * GLPbo::elem_cnt,
		reinterpret_cast<GLvoid*>(idx_vtx.data()), GL_DYNAMIC_STORAGE_BIT);

	glVertexArrayElementBuffer(vaoid, ebo_hdl);
	//attach the index buffer to the vertex array .
	glBindVertexArray(0);
}

/**
 * @brief sets up the shader program for rendering a full-screen quad with texture mapping
 * this function compiles the vertex and fragment shaders from the provided shader source code strings.
 * it creates a shader program object, attaches the compiled shaders, and links the program.
 * it also validates the linked program to check for any errors.
 * if any compilation, linking, or validation step fails, an error message is printed and the program exits.
 */
void GLPbo::setup_shdrpgm()
{
	const GLchar* vertexShdr = R"(
    #version 450 core

    layout (location=0) in vec2 iVertexPosition;
    layout (location=1) in vec2 iVertexTexture;

    layout (location=1) out vec2 oTexCoord;

    void main(void){
        gl_Position = vec4(iVertexPosition, 0.0, 1.0);
        oTexCoord = iVertexTexture;
    }
    )";

	const GLchar* fragShdr = R"(
    #version 450 core

    layout (location = 1) in vec2 iTexCoord;
    layout (location = 0) out vec4 oFragColor;
    uniform sampler2D Tex2d;
    
    void main()
	{
        oFragColor = texture(Tex2d,iTexCoord);
    }

    )";

	std::vector<std::pair<GLenum, std::string>> shdr_files;
	shdr_files.emplace_back(std::make_pair(GL_VERTEX_SHADER, vertexShdr));
	shdr_files.emplace_back(std::make_pair(GL_FRAGMENT_SHADER, fragShdr));

	for (auto &shader : shdr_files)
	{
		if (!shdr_pgm.CompileShaderFromString(shader.first, shader.second))
		{
			std::cout << "Unable to compile shader programs from string" << "\n";
			std::cout << shdr_pgm.GetLog() << std::endl;
			std::exit(EXIT_FAILURE);
		}
	}

	if (!shdr_pgm.Link())
	{
		std::cout << "Unable to link shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}

	if (!shdr_pgm.Validate())
	{
		std::cout << "Unable to validate shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}

	//shdr_pgm.Link(shdr_files);
	if (GL_FALSE == shdr_pgm.IsLinked())
	{
		std::cout << "Unable to compile/link/validate shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}


}

/*
 *Define overloaded functions GLPbo::set_clear_color() that set static data member
 *GLPbo::clear_clr with 32-bit RGBA values specified by function parameters. These
 *functions emulate the behavior of GL command glClearColor()
*/
void GLPbo::set_clear_color(GLPbo::Color color)
{
	//set color to the color itself
	clear_clr = color;
}

/*
 *Define overloaded functions GLPbo::set_clear_color() that set static data member
 *GLPbo::clear_clr with 32-bit RGBA values specified by function parameters. These
 *functions emulate the behavior of GL command glClearColor()  
*/
void GLPbo::set_clear_color(GLubyte r, GLubyte g, GLubyte b, GLubyte a)
{
	//set all color rbg into the respeective rgb
	clear_clr = Color(r, g, b, a);
}

/*
 *Define GLPbo::clear_color_buffer() . This function emulates GL command
 *glClear(GL_COLOR_BUFFER_BIT) by using pointer GLPbo::ptr_to_pbo to fill the PBO's data
 *store with RGBA value in GLPbo::clear_clr . Since you'll write millions of bytes, think of how
 *this can be done as efficiently as possible - potential candidates from the standard library
 *include std::fill or std::fill_n or combinations of these fill functions with
 *std::memcpy. 
*/
void GLPbo::clear_color_buffer()
{
	//using pointer GLPbo::ptr_to_pbo to fill the PBO's data using std::fill_n
	std::fill_n(ptr_to_pbo, pixel_cnt, clear_clr);
}

/**
 * @brief Cleans up the resources used by GLPbo.
 * this function deletes the vertex array object, pixel buffer object, and texture object.
 * it sets the corresponding handles to 0 to indicate that the resources are no longer valid.
 */
void GLPbo::cleanup()
{
	//delete the vertex array data
	glDeleteVertexArrays(1, &vaoid);
	vaoid = 0;
	//delete the pixel buffer data
	glDeleteBuffers(1, &pboid);
	pboid = 0;
	//delete the texture data
	glDeleteTextures(1, &texid);
	texid = 0;
}
