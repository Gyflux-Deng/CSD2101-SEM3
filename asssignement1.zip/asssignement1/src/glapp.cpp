/*!
@file    glapp.cpp
@author  pghali@digipen.edu
@co-author Maojie.deng@digipen.edu
@date    5/10/2023

This file implements functionality useful and necessary to build OpenGL
applications including use of external APIs such as GLFW to create a
window and start up an OpenGL context and to extract function pointers
to OpenGL implementations.

*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */
#include <glapp.h>
//include the glhelper.h to allow glapp to use the functions written in glhelper
#include <glhelper.h>
//uses math to calculate graphic for linearly interpolating the color components.
#include "math.h"
//uses array library for me to access to array function
#include <array>
//uses iostream library for printing out data
#include <iostream>
//sstream to print out data ontop of the visual studio on top of the windows
#include <sstream>
#include <iomanip>

/*                                                   objects with file scope
----------------------------------------------------------------------------- */
//local file global variable
//set a pie color and everything needed in a color and interpolation
static float colorRed1 = 0.0f;
static float colorGreen1 = 0.0f;
static float colorBlue1 = 0.0f;
static float colorRed2 = 0.0f;
static float colorGreen2 = 0.0f;
static float colorBlue2 = 0.0f;

//interpolated distance
static float distanceInterpolated = 0.0f;
static float lerpX = 1.f;
static float lerpY = 1.f;
static float t = 0.0f;
static float t1 = 0.0f;
static float finalColorRed = 0.0f;
static float finalColorBlue = 0.0f;
static float finalColorGreen = 0.0f;

GLApp::GLModel GLApp::mdl{};
void GLApp::init() 
{
	//part 1: clear colorbuffer with RGBA value in glClearColor
	//set the color to 0,1,0,1 using glClearColor
	glClearColor(0.f, 1.f, 0.f, 1.f);

	//part 2: use entire window as view port
	//set the viewport to the whole window size
	glViewport(0, 0, GLHelper::width, GLHelper::height);

	//part 3
	mdl.setup_shdrpgm();
	mdl.setup_vao();
	
}

void GLApp::update() 
{
	//change color code using interpolating lerp

	//increment distance interpolated by delta time
	distanceInterpolated += static_cast<float>(GLHelper::delta_time) * 0.1f;
	//loop the distanceInterpolated value to prevent overflow
	distanceInterpolated = fmodf(distanceInterpolated, static_cast<float>(SIZE_MAX));
	//calculate t, which is the normalized distance between 0 and 1
	t = distanceInterpolated / SIZE_MAX;
	//calculate the opposite of t and store it in t1
	t1 = 1.0f - t;
	//calculate the color component of the sine wave at the current distanceInterpolated position
	colorRed1 = lerpY * sinf(lerpX * (distanceInterpolated)+2.f) + 1.f;
	colorGreen1 = lerpY * sinf(lerpX - 5.0f * (distanceInterpolated)+2.f) + 1.f;
	colorBlue1 = lerpY * sinf(lerpX + 5.0f * (distanceInterpolated)+2.f) + 1.f;

	//calculate the color component of the sine wave at the next distanceInterpolated position
	colorRed2 = lerpY * sinf(lerpX * (distanceInterpolated + 2.0f) + 2.f) + 1.f;
	colorGreen2 = lerpY * sinf(lerpX - 5.0f * (distanceInterpolated + 1.0f) + 2.f) + 1.f;
	colorBlue2 = lerpY * sinf(lerpX + 5.0f * (distanceInterpolated + 1.0f) + 2.f) + 1.f;

	//calculate the final color by interpolating between the two color components
	finalColorRed = colorRed1 * t1 + colorRed2 * t;
	finalColorBlue = colorBlue1 * t1 + colorBlue2 * t;
	finalColorGreen = colorGreen1 * t1 + colorGreen2 * t;
	
}

/**
\ brief Sets up the vertex array object (VAO) for the model.
  its to draw triangle at the range of [-0.5,0.5]
  and color at  [1.f, 0.f, 0.f] to [0.f, 1.f, 0.f]
*/
void GLApp::GLModel::setup_vao()
{
	//we'll define a rectangle in normalizeed device coordinates (NDC)
	// coordinates that has one-fourth the area of the window.
	// The NDC coordinates for a window range from [-1, 1] along both
	// both the X- and Y-axes. Therefore, the rectangle's (x, y) position
	// coordinates are in range [-0.5, 0.5]
	// We're using NDC coordinates, because we don't want to specify
	// a "model-to-world-to-view-to-clip" transform to the vertex shader.

	//define the positions of the 4 vertices of a square in the 2D plane
	std::array<glm::vec2, 4> pos_vtx
	{
		glm::vec2(0.5f,-0.5f), glm::vec2(0.5f, 0.5f),
		glm::vec2(-0.5f,0.5f), glm::vec2(-0.5f, -0.5f)
	};

	//define the color of each vertex
	std::array<glm::vec3, 4> clr_vtx
	{

		glm::vec3(1.f, 0.f, 0.f), glm::vec3(0.f, 1.f, 0.f),
		glm::vec3(0.f, 0.f, 1.f), glm::vec3(1.f, 1.f, 1.f)
	};
	//create a buffer object to store the vertex data
	GLuint vbo_hdl;
	//allocate storage for the buffer object and specify the usage as dynamic
	glCreateBuffers(1, &vbo_hdl); glNamedBufferStorage(vbo_hdl,
		sizeof(glm::vec2) * pos_vtx.size() + sizeof(glm::vec3) * clr_vtx.size(), nullptr, GL_DYNAMIC_STORAGE_BIT);
	//copy the position data to the buffer object
	glNamedBufferSubData(vbo_hdl, 0, sizeof(glm::vec2) * pos_vtx.size(), pos_vtx.data());
	//copy the color data to the buffer object after the position data
	glNamedBufferSubData(vbo_hdl, sizeof(glm::vec2) * pos_vtx.size(), sizeof(glm::vec3) * clr_vtx.size(), clr_vtx.data());

	//get the maximum number of vertex attributes supported by the implementation
	GLint max_vtx_attribs;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &max_vtx_attribs);
	std::cout << "Maximum vertex attributes: " << max_vtx_attribs << '\n';

	GLint max_vtx_binding_buffer;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIB_BINDINGS, &max_vtx_binding_buffer);
	std::cout << "Maximum vertex buffer bindings: " << max_vtx_binding_buffer << '\n';

	//create a vertex array object to store the vertex attribute state
	glCreateVertexArrays(1, &vaoid);

	//enable vertex attribute 8 and bind it to vertex buffer binding point 3
	glEnableVertexArrayAttrib(vaoid, 8);
	glVertexArrayVertexBuffer(vaoid, 3, vbo_hdl, 0, sizeof(glm::vec2));

	//specify the format of the vertex attribute data for attribute 8
	glVertexArrayAttribFormat(vaoid, 8, 2, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 8
	glVertexArrayAttribBinding(vaoid, 8, 3);

	//enable vertex attribute 9 and bind it to vertex buffer binding point 4
	glEnableVertexArrayAttrib(vaoid, 9);
	glVertexArrayVertexBuffer(vaoid, 4, vbo_hdl, sizeof(glm::vec2) * pos_vtx.size(), sizeof(glm::vec3));

	//specify the format of the vertex attribute data for attribute 9
	glVertexArrayAttribFormat(vaoid, 9, 3, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 9
	glVertexArrayAttribBinding(vaoid, 9, 4);

	//specify the primitive type as triangles
	primitive_type = GL_TRIANGLES;

	//define the indices of the vertices that form the two triangles
	std::array<GLushort, 6> idx_vtx
	{
		0, 1, 2,
		2, 3, 0
	};

	idx_elem_cnt = idx_vtx.size();

	//the number of indices in the index array is stored in 'idx_elem_cnt'.
	GLuint ebo_hdl;
	glCreateBuffers(1, &ebo_hdl);

	//generate a buffer object for the index data and store its handle in ebo_hdl.
	glNamedBufferStorage(ebo_hdl, sizeof(GLushort) * idx_elem_cnt,
		reinterpret_cast<GLvoid*>(idx_vtx.data()), GL_DYNAMIC_STORAGE_BIT);

	glVertexArrayElementBuffer(vaoid, ebo_hdl);
	//attach the index buffer to the vertex array .
	glBindVertexArray(0);
}

/**
\brief Sets up the shader program by compiling, linking and validating the shader files
*/
void GLApp::GLModel::setup_shdrpgm()
{
	//vector array to hold shader file
	std::vector<std::pair<GLenum, std::string>> shdr_files;
	//add vertex shader to the vector
	shdr_files.emplace_back(std::make_pair(GL_VERTEX_SHADER, "../shaders/my-tutorial-1.vert"));
	//add fragment shader to the vector
	shdr_files.emplace_back(std::make_pair(GL_FRAGMENT_SHADER, "../shaders/my-tutorial-1.frag"));
	// compile , link and validate the shader file u assign in the vector
	shdr_pgm.CompileLinkValidate(shdr_files);
	//check if shader file linked if fail print out failure
	if (shdr_pgm.IsLinked() == GL_FALSE)
	{
		//print ouf failiure if the linkage fails in the shader file
		std::cout << "Brother, the shaders have failed to compile / link / validate" << "\n";
		std::cout << shdr_pgm.GetLog() << "\n";
		std::exit(EXIT_FAILURE);
	}
}
/**
 \brief This method renders the model by using a specific shader program and VAO object.
*/
void GLApp::GLModel::draw()
{
	// there are many shader programs initialized - here we're saying
	// which specific shader program should be used to render geometry
	shdr_pgm.Use();
	// there are many models, each with their own initialized VAO object
	// here, we're saying which VAO's state should be used to set up pipe
	glBindVertexArray(vaoid);
	// here, we're saying what primitive is to be rendered and how many
	// such primitives exist.
	// the graphics driver knows where to get the indices because the VAO
	// containing this state information has been made current ...
	glDrawElements(primitive_type, idx_elem_cnt, GL_UNSIGNED_SHORT, NULL);
	// after completing the rendering, we tell the driver that VAO
	// vaoid and current shader program are no longer current
	glBindVertexArray(0);
	shdr_pgm.UnUse();
}
/**
  \brief Draws the scene.
   This function is responsible for drawing the scene in the OpenGL window.
 */
void GLApp::draw() 
{
	//call the glfunctiosn clear to update the color buffer
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(finalColorRed, finalColorGreen, finalColorBlue, 1.f);
	mdl.draw();

	//u store the string into streamdata
	std::stringstream strData;
	//print out with the percision of setprecision
	strData << std::fixed << std::setprecision(2) << GLHelper::title << " | " << "Maojie Deng" << " | " << GLHelper::fps;
	glfwSetWindowTitle(GLHelper::ptr_window, strData.str().c_str());

}



void GLApp::cleanup() 
{
  // empty for now
}
