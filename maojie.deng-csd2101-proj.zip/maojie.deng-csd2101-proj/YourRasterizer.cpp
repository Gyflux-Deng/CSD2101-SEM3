/*!
@file    YourRasterizer.cpp
@author  Prasanna Ghali       (pghali@digipen.edu)
@co-author maojie deng        (maojie.deng@digipen.edu)
@date 8/3/2023
CVS: $Id: YourRasterizer.cpp,v 1.13 2005/03/15 23:34:41 jmp Exp $

@brief
YourRasterizer.cpp functions used to render  a filled triangle on the graphics pipeline. 
It takes three gfxVertex objects representing the vertices of the triangle to be drawn.

All content (c) 2002 DigiPen Institute of Technology, all rights reserved.
*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */

#include "YourRasterizer.h"

#include "iostream"

/*                                                                  functions
----------------------------------------------------------------------------- */
/*  _________________________________________________________________________ */

void YourRasterizer::
DrawFilled(gfxGraphicsPipe *dev, gfxVertex const&	v0, 
           gfxVertex const&	v1, gfxVertex const&	v2)


/*! Render a triangle in filled mode using 3 device-frame points.
  @param dev <->  Pointer to the pipe to render to.
  @param v0  -->  First vertex.
  @param v1  -->  Second vertex.
  @param v2  -->  Third vertex.

READ THIS FUNCTION HEADER CAREFULLY:

Begin by reading the declaration of type gfxVertex (in Vertex.h) so that
you're aware of the data encapsulated by a gfxVertex object.

-------------------------------------------------------------------------------
Triangles can be rendered in one of three ways:
1) Texture mapped (but not lit)
2) Lit (but not texture mapped)
3) Lit and texture mapped

To reduce computational overheads, this software pipe doesn't implement both
lighting and texture mapping on objects - it is one or the other.
The current rendering state of the triangle (or object) is determined by
the following call:

  unsigned int  *tex = dev->GetCurrentTexture();
    
If the function returns 0 (a null pointer), there is no texture state bound
to the currently-drawing triangle. This means that the object is lit but not 
texture mapped. Otherwise if the function returns an address, the object 
is texture mapped but not lit. The texture image is buffered in memory as
a sequence of 32-bit unsigned integral values in xxRRGGBB format which
can be directly written to the colorbuffer without any transformations.
The width and height of the texture image can be determined by the calls:

 unsigned int  tW = dev->GetCurrentTextureWidth();
 unsigned int  tH = dev->GetCurrentTextureHeight();

NOTE: Assume that GL_REPEAT is the default wrapping mode for both s and t
texture coordinates.
-------------------------------------------------------------------------------

Testing depth buffer state of the pipe:
Users can choose to turn on or off the depth buffering algorithm. The current
state of the pipe can be determined by the following call:
    
  bool          wdepth    = dev->DepthTestEnabled();

If DepthTestEnabled() returns 0, depth buffering is disabled, otherwise
it is enabled.
-------------------------------------------------------------------------------

Which interpolation scheme is to be used by the rasterizer to interpolate
vertex color and texture coordinates?
Since users can set the graphics pipe's to render scenes using linear or
hyperbolic interpolation, your rasterizer must implement both these
interpolation schemes. The current interpolation state of the graphics pipe
can be determined by the call:

  gfxInterpMode im = dev->GetInterpMode();

Enumeration type gfxInterpMode is declared in GraphicsPipe.h with
enumeration constants: GFX_LINEAR_INTERP or GFX_HYPERBOLIC_INTERP.
-------------------------------------------------------------------------------

How is the front colorbuffer accessed?
The dimensions of the colorbuffer are specified by the user and have values
determined by the read-only sWindowWidth and sWindowHeight variables defined
at file-scope in main.cpp. The calls

  unsigned int  *frameBuf = dev->GetFrameBuffer();
  size_t        w         = dev->GetWidth();
  size_t        h         = dev->GetHeight();

returns the address of the first element, the width, and the height of the
of the colorbuffer. The colorbuffer is a linear array of 32-bit unsigned 
integral values. The pixel form is xxRRGGBB - the most significant 8 bits 
are unused. To write to this colorbuffer, you must convert the normalized 
color components in range [0.f, 1.f] from the interpolator into values in 
range [0, 255] and pack the components into a 32-bit integral value with 
format xxRRGGBB.
-------------------------------------------------------------------------------

How is the depthbuffer accessed?
The depthbuffer's dimensions are exactly the same as the colorbuffer. The call

  float         *depthBuf = dev->GetDepthBuffer();

returns the address of the first element of the depthbuffer. As can be seen the
depthbuffer stores depthvalues in the range [0.f, 1.f]. The depthbuffer
has the same dimensions as the colorbuffer.
-------------------------------------------------------------------------------

What are the coordinate conventions of the colorbuffer, depthbuffer and
texels in the texture image?
Memory for these buffer is allocated by Windows which is also used to blit
the contents of the colorbuffer to the display device's video memory.
Windows defines the colorbuffer with the convention that the origin is at
the upper-left corner. This means that assigning the value 0x00ff0000 to
frameBuf[0] will paint the upper-left corner with red color. Reading a
depth value from the first location of the depthbuffer provides the depth
value of the upper-left corner. Simiarly, reading a texel from the first
location of the texture image will return the texel associated with the
upper-left corner. However, the graphics pipe simulates OpenGL and therefore 
generates device coordinates with the bottom-left corner as the origin. All of 
this means that it is your responsibility to map the OpenGL device (or viewport 
or window) coordinates from the bottom-left corner to upper-left corner.
*/

/**
 * @brief Draws a filled triangle using rasterization.
 * This function performs the rasterization of a filled triangle defined by three vertices
 * v0, v1, and v2. It applies backface culling to eliminate triangles that are not facing
 * the camera. Then, it computes the axis-aligned bounding box (AABB) for the triangle to
 * determine the region to be rasterized. The function uses edge equations to determine if
 * each pixel inside the bounding box is within the triangle's edges. If a pixel is inside
 * the triangle, the function performs depth interpolation to calculate its depth (z-coordinate).
 * If the calculated depth is within the depth buffer limits and closer to the camera than
 * the existing depth value, the function calculates the pixel's color. The color is either
 * interpolated from the triangle's vertex colors or obtained from texture interpolation if
 * a texture is available. Finally, the pixel is drawn to the screen using the DrawPoint2
 * function provided by the gfxGraphicsPipe class.
 * @param dev Pointer to the gfxGraphicsPipe object representing the graphics pipeline.
 * @param v0 First vertex of the triangle.
 * @param v1 Second vertex of the triangle.
 * @param v2 Third vertex of the triangle.
 */
{
  if (!CullBackFacesCCW(v0.x_d, v0.y_d,  v1.x_d, v1.y_d,v2.x_d,v2.y_d))
  {
	  return;
  }
  //compute the axis-aligned bounding box (AABB) for the triangle
  int xmin = std::min({ static_cast<int>(v0.x_d), static_cast<int>(v1.x_d), static_cast<int>(v2.x_d) });
  int xmax = std::max({ static_cast<int>(v0.x_d), static_cast<int>(v1.x_d), static_cast<int>(v2.x_d) }) + 1;
  int ymin = std::min({ static_cast<int>(v0.y_d), static_cast<int>(v1.y_d), static_cast<int>(v2.y_d) });
  int ymax = std::max({ static_cast<int>(v0.y_d), static_cast<int>(v1.y_d), static_cast<int>(v2.y_d) }) + 1;

  //compute the surface area of the triangle
  float surfaceArea = 1.0f / ((v1.x_d - v0.x_d) * (v2.y_d - v0.y_d) - (v2.x_d - v0.x_d) * (v1.y_d - v0.y_d));

  //evaluate the edge equations at the starting point of the AABB
  gfxVector3 pointSample(static_cast<float>(xmin) + 0.5f, static_cast<float>(ymin) + 0.5f, 0.0f);

  glm::vec3 edge0 = edgeEquation(v1.x_d, v1.y_d, v2.x_d, v2.y_d);
  glm::vec3 edge1 = edgeEquation(v2.x_d, v2.y_d, v0.x_d, v0.y_d);
  glm::vec3 edge2 = edgeEquation(v0.x_d, v0.y_d, v1.x_d, v1.y_d);

  float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
  float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
  float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

  //compute the edge increments
  float edge0XInc = edge0.x;
  float edge1XInc = edge1.x;
  float edge2XInc = edge2.x;
  float edge0YInc = edge0.y;
  float edge1YInc = edge1.y;
  float edge2YInc = edge2.y;

  bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
  bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
  bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

  //store color 
  glm::vec3 clr0 = { v0.r,v0.g,v0.b };
  glm::vec3 clr1 = { v1.r,v1.g,v1.b }; 
  glm::vec3 clr2 = { v2.r,v2.g,v2.b };

  //store texture
  glm::vec2 tex0 = { v0.s,v0.t };
  glm::vec2 tex1 = { v1.s,v1.t };
  glm::vec2 tex2 = { v2.s,v2.t };

  //all the pointer im using
  unsigned int* tex = dev->GetCurrentTexture();
  unsigned int  tW = dev->GetCurrentTextureWidth();
  unsigned int  tH = dev->GetCurrentTextureHeight();
  float* depthBuf = dev->GetDepthBuffer();
  size_t        w = dev->GetWidth();
  size_t        h = dev->GetHeight();
  
  gfxVertex screenPoint{};
  for (int y = ymin; y < ymax; ++y)
  {
	  //sart values for horizontal spans
	  float hEval0 = Eval0;
	  float hEval1 = Eval1;
	  float hEval2 = Eval2;
	  
	 
	  for (int x = xmin; x < xmax; ++x)
	  {
		  //siccsoring for depth value
		  if ((x >= 0 && x < static_cast<int>(w)) && (y >= 0 && y < static_cast<int>(h)))
		  {
			  if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			  {
				  //calculate depth value
				  float depthZ = ((hEval0 * v0.z_d) + (hEval1 * v1.z_d) + (hEval2 * v2.z_d)) * surfaceArea;

				  int depthPoint = static_cast<int>((y * w) + x);
				  if ((depthZ < depthBuf[depthPoint]) && (depthZ >= 0) && (depthZ < static_cast<float>((w * h))))
				  {

					  //store the vakye if loop value of x and y so i can put into drawpoint position
					  screenPoint.x_d = static_cast<float>(x);
					  screenPoint.y_d = static_cast<float>(y);
					  //check texture if no texture do color else do texture
					  if (tex == 0)
					  {
						  if (dev->DepthTestEnabled())
						  {
							  depthBuf[depthPoint] = depthZ;
						  }

						  glm::vec3 clr{ (((hEval0)*clr0) + ((hEval1)*clr1) + ((hEval2)*clr2)) };
						  clr = (clr * 255.f) * surfaceArea;
						  unsigned int unsignclr = static_cast<signed int>(clr.r) << 16 | static_cast<signed int>(clr.g) << 8 | static_cast<signed int>(clr.b);
						  DrawPoint2(dev, screenPoint, unsignclr);
					  }
					  else
					  {
						  //get texture interpolated values
						  glm::vec2 uv = ((hEval0 * tex0) + (hEval1 * tex1) + (hEval2 * tex2)) * surfaceArea;
						 
						  //wrapping
						  if (uv.x > 1.0f)
						  {
							  uv.x = uv.x - static_cast<int>(uv.x);
						  }

						  if (uv.y > 1.0f)
						  {
							  uv.y = uv.y - static_cast<int>(uv.y);
						  }
						  uv.x = static_cast<float>(floorf(uv.x * tW));
						  uv.y = static_cast<float>(floorf(uv.y * tH));

						  //set the wrapping value for the texture to load
						  int wrappingValue = static_cast<int>((uv.y * tW) + uv.x);

						  int color = tex[wrappingValue];

						  DrawPoint2(dev, screenPoint, color);

					  }

				  }

			  }
		  }
		 
		  //incrementally update hEval0, hEval1, hEval2
		  hEval0 += edge0XInc;
		  hEval1 += edge1XInc;
		  hEval2 += edge2XInc;
	  }

	  //incrementally update Eval0, Eval1, Eval2
	  Eval0 += edge0YInc;
	  Eval1 += edge1YInc;
	  Eval2 += edge2YInc;
  }

}


/*  _________________________________________________________________________ */
/**
 * @brief Renders a point in the device frame.
 * This function renders a single point in the device frame coordinates, previously computed
 * for the given vertex v0. If the point is outside the
 * scissor rectangle, it skips writing to the frame buffer. Otherwise, the function accesses
 * the framebuffer, which is a linear array of 32-bit pixels, and sets the corresponding pixel
 * at the calculated (x, y) position to black (color value 0) to render the point.
 * @param dev Pointer to the gfxGraphicsPipe object representing the graphics pipeline.
 * @param v0 Vertex with device frame coordinates previously computed
 */
void YourRasterizer::
DrawPoint(gfxGraphicsPipe *dev, gfxVertex const&	v0)
  /*! Render a device frame point.

      @param dev -->  Pointer to the pipe to render to.
      @param v0  -->  Vertex with device frame coordinates previously computed.

      The framebuffer is a linear array of 32-bit pixels.
      fb[y * width + x] will access a pixel at (x, y). The
      pixel format is xxRRGGBB (thus the shifting that's
      going on to pack the color components into a single
      32-bit pixel value.
  */
{
    size_t xCoord = static_cast<size_t>(v0.x_d);
	size_t yCoord = static_cast<size_t>(dev->GetHeight() - v0.y_d);
	size_t offSet = yCoord * dev->GetWidth() + xCoord;

	//perform scissoring with the entire window as the scissor rectangle
	if (xCoord < 0 || xCoord > dev->GetWidth() || yCoord < 0 || yCoord >= dev->GetHeight() || offSet >= dev->GetWidth() * dev->GetHeight())
	{
		//pixel is outside the scissor rectangle, skip writing
		return;
	}
   
	unsigned int* frameBuf = dev->GetFrameBuffer();
    //set the line to black
    frameBuf[offSet] = 0;
}

/**
 * @brief Renders a point in the device frame.
 * This function renders a single point in the device frame coordinates, previously computed
 * for the given vertex v0. If the point is outside the
 * scissor rectangle, it skips writing to the frame buffer. Otherwise, the function accesses
 * the framebuffer, which is a linear array of 32-bit pixels, and sets the corresponding pixel
 * at the calculated (x, y) position to black (color value 0) to render the point.
 * @param dev Pointer to the gfxGraphicsPipe object representing the graphics pipeline.
 * @param v0 Vertex with device frame coordinates previously computed
 * @param color unsigned int of the color pass tru to have color for texture, triangle
 */
void YourRasterizer::DrawPoint2(gfxGraphicsPipe* dev, gfxVertex const& v0, unsigned int color)
{
	size_t xCoord = static_cast<int>(v0.x_d);
	size_t yCoord = static_cast<int>(dev->GetHeight() - v0.y_d);
	size_t offSet = yCoord * dev->GetWidth() + xCoord;

	//perform scissoring with the entire window as the scissor rectangle
	if (xCoord < 0 || xCoord > dev->GetWidth() || yCoord < 0 || yCoord >= dev->GetHeight())
	{
		//pixel is outside the scissor rectangle, skip writing
		return;
	}
	unsigned int* frameBuf = dev->GetFrameBuffer();
	//set the color to the pixel
	frameBuf[offSet] = color;
}


/*  _________________________________________________________________________ */
/**
 *@brief renders a line using the Bresenham algorithm in the specified octant.
 *This function renders a line segment between two points using the Bresenham algorithm.
 *The algorithm used depends on the value of the bresenham1256 parameter.
 *@param *dev pointer of grpahic pipe
 *@param v0 first triangle 
 *@param v1 second triangle 
*/
void YourRasterizer::
DrawLine(gfxGraphicsPipe *dev, gfxVertex const&	v0, gfxVertex const&	v1)
/*! Render a line segment between 2 device frame points.

    @param dev -->  Pointer to the pipe to render to.
    @param v0  -->  First vertex.
    @param v1  -->  Second vertex.
*/
{
	//so i can modified value 
	gfxVertex p0 = v0;
	gfxVertex p1 = v1;
	////for octian 0 3 4 7
	int dx = static_cast<int>(p1.x_d) - static_cast<int>(p0.x_d);
	int dy = static_cast<int>(p1.y_d) - static_cast<int>(p0.y_d);

	////determine the step directions for x and y
	int xstep = (dx < 0) ? -1 : 1;
	int ystep = (dy < 0) ? -1 : 1;

	////take absolute values of dx and dy
	dx = (dx < 0) ? -dx : dx;
	dy = (dy < 0) ? -dy : dy;

	////renders a line using Bresenham's line drawing algorithm for octants 1, 2, 5, and 6.
	if (dy <= dx)
	{
		//calculate decision variable and error adjustments
		int d = 2 * dy - dx;
		int dmin = 2 * dy;
		int dmaj = 2 * dy - 2 * dx;
		//set the initial pixel
		DrawPoint(dev, v0);
		//iterate through the pixels along the line x
		while (--dx > 0)
		{
			//update y coordinate based on decision variable
			p0.y_d += (d > 0) ? ystep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			p0.x_d += xstep;
			//set the pixel
			DrawPoint(dev, p0);
		}
	}
	else
	{
		//calculate decision variable and error adjustments
		int d = 2 * dx - dy;
		int dmin = 2 * dx;
		int dmaj = 2 * dx - 2 * dy;
		//set the initial pixel
		DrawPoint(dev, p0);
		//iterate through the pixels along the line y
		while (--dy > 0)
		{
			//update y coordinate based on decision variable
			p0.x_d += (d > 0) ? xstep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			p0.y_d += ystep;
			//set the pixel
			DrawPoint(dev,p0);
		}
	}

}


/**
 * @brief draws a wireframe triangle using Bresenham's line algorithm.
 * @param dev is the pointer to have all the graphice pipeline
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 */
/*  _________________________________________________________________________ */
void YourRasterizer::
DrawWireframe(gfxGraphicsPipe* dev,
              gfxVertex const& v0,
              gfxVertex const& v1,
              gfxVertex const& v2)
/*! Render a triangle in wireframe mode using 3 device-frame points.

    @param dev -->  Pointer to the pipe to render to.
    @param v0  -->  First vertex.
    @param v1  -->  Second vertex.
    @param v2  -->  Third vertex.
*/
{
    //check if back faces should be culled
    if (!CullBackFacesCCW(v0.x_d, v0.y_d,v1.x_d, v1.y_d,v2.x_d, v2.y_d))
    {
        return ;
    }

  DrawLine(dev, v0, v1);
  DrawLine(dev, v1, v2);
  DrawLine(dev, v2, v0);
  
}

/**
 * @brief calculates the coefficients of the edge equation given two points on the edge.
 * @param p1 the coordinates of the first point on the edge.
 * @param p2 tthe coordinates of the second point on the edge.
 * @return the edge equation coefficients as a 3D vector (a, b, c) where ax + by + c = 0.
 */
glm::vec3 YourRasterizer::edgeEquation(float p0x, float p0y, float p1x, float p1y)
{
    //calculate the coefficients of the edge equation
    float pointA = p0y - p1y;
    float pointB = p1x - p0x;
    float pointC = (p0x * (p1y - p0y)) - (p0y * (p1x - p0x));

    //return the edge equation coefficients as a 3D vector
    return glm::vec3(pointA, pointB, pointC);
}

/**
 * @brief culls back-faces of a triangle using the CCW (Counter Clockwise) convention.
 * @param pos1 The coordinates of the first vertex of the triangle.
 * @param pos2 The coordinates of the second vertex of the triangle.
 * @param pos3 The coordinates of the third vertex of the triangle.
 * @return true if the triangle is not a back-face (CCW), false otherwise.
 */
bool YourRasterizer::CullBackFacesCCW(float pos1x, float pos1y,  float pos2x, float pos2y,  float pos3x, float pos3y)
{
    float crossProduct = (pos2x - pos1x) * (pos3y - pos1y) - (pos2y - pos1y) * (pos3x - pos1x);

    //if the cross product is positive, the triangle is facing towards the camera (CCW)
    //if the cross product is negative, the triangle is facing away from the camera (back-face)
    return crossProduct > 0.f;
}


/**
 *@brief checks if a point is in the top-left region defined by an edge equation.
 *@param edge the coefficients of the edge equation in the form of a 3D vector.
 *@param point the coordinates of the point to be checked in the form of a 3D vector.
 *@return true if the point is in the top-left region, false otherwise.
 */
bool YourRasterizer::PointInEdgeTopLeft(float eval, bool tl)
{

	return(eval > 0.f || (eval == 0.f && tl)) ? true : false;
}

