/*!
@file    YourCullerClipper.cpp
@author  Prasanna Ghali       (pghali@digipen.edu)
@co-author Maojie deng		  (maojie.deng@digipen.edu)
@date 8/3/2023
@brief 

YourCullerClipping cpp has functions that  calculates a frustum (viewing volume) based on 
the given perspective matrix.It extracts the six planes 
(left, right, bottom, top, near, far) that define the frustum.
functions that performs frustum culling using a bounding sphere and a frustum.
functions that  clips a triangle against the 
frustum's clipping region using the provided output code (outcode) and the vertex buffer

All content (c) 2002 DigiPen Institute of Technology, all rights reserved.
*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */

#include "YourCullerClipper.h"
#include <iostream>

/*                                                                  functions
----------------------------------------------------------------------------- */
/*  _________________________________________________________________________ */
gfxFrustum YourClipper::
/*! Get view frame frustum plane equations

  @param perspective_mtx	--> Matrix manifestation of perspective (or, orthographic)
  transform.

  @return	--> gfxFrustum
  Plane equations of the six surfaces that specify the view volume in view frame.
*/
/**
 * @brief compute the frustum planes from the given perspective matrix.
 * This function calculates the six frustum planes (left, right, bottom, top, near, far)
 * from the input perspective matrix. The frustum planes define the viewing frustum
 * and are used for various graphics culling and clipping operations.
 * @param perspective_mtx The perspective matrix representing the projection transform.                     
 * @return gfxFrustum object containing the computed frustum planes.
 */
ComputeFrustum(gfxMatrix4 const& perspective_mtx)
{
	  //left side = -r0 -r3
	  //right side = r0 -r3
	  //btm = -r1 -r3
	  //top = r1-r3
	  //near = -r2-r3
	  //far = r2-r3
	gfxVector4 r0 = perspective_mtx.GetRow4(0);
	gfxVector4 r1 = perspective_mtx.GetRow4(1);
	gfxVector4 r2 = perspective_mtx.GetRow4(2);
	gfxVector4 r3 = perspective_mtx.GetRow4(3);
	
	gfxVector4 leftSide = (-1 * r0 )- r3;
	gfxVector4 rightSide = (r0 - r3);
	gfxVector4 btm = (-1 * r1) - r3;
	gfxVector4 top = (r1 - r3);
	gfxVector4 nearside = (-1 * r2) - r3;
	gfxVector4 farside = (r2 - r3);

	//create a gameobject
	gfxFrustum gO;

	//set the vector of the calculated position into leftside
	gO.l = { leftSide.x,leftSide.y,leftSide.z,leftSide.w };
	//set the vector of the calculated position into rightside
	gO.r = { rightSide.x,rightSide.y,rightSide.z,rightSide.w };
	//set the vector of the calculated position into btmside
	gO.b = { btm.x,btm.y,btm.z,btm.w };
	//set the vector of the calculated position into topside
	gO.t = { top.x,top.y,top.z,top.w };
	//set the vector of the calculated position into nearside
	gO.n = { nearside.x,nearside.y,nearside.z,nearside.w };
	//set the vector of the calculated position into farside
	gO.f = { farside.x,farside.y,farside.z,farside.w };
		
    return gO;
}

/*  _________________________________________________________________________ */
bool YourClipper::
/*! Performing culling.

@param bs		--> View-frame definition of the bounding sphere of object
which is being tested for inclusion, exclusion, or
intersection with view frustum.
@param f		--> View-frame frustum plane equations.
@param oc		--> Six-bit flag specifying the frustum planes intersected
by bounding sphere of object. A given bit of the outcode
is set if the sphere crosses the appropriate plane for that
outcode bit - otherwise the bit is cleared.

@return
True if the vertices bounded by the sphere should be culled.
False otherwise.

If the return value is false, the outcode oc indicates which planes
the sphere intersects with. A given bit of the outcode is set if the
sphere crosses the appropriate plane for that outcode bit.
*/

/**
 * @brief perform frustum culling using bounding sphere test.
 * This function performs frustum culling using the bounding sphere test with the given bounding sphere
 * and frustum.The function checks whether the bounding sphere is completely inside or partially outside the frustum,
 * and provides an output code (*ptr_outcode) to identify the frustum planes that the sphere intersects.
 * @param bounding_sphere The bounding sphere to be tested against the frustum.
 * @param frustum The frustum used for culling
 * @param ptr_outcode A pointer to a gfxOutCode integer that will store the output code indicating the intersecting frustum planes.
 * @return A boolean value indicating whether the bounding sphere is partially or completely outside the frustum.
 */
Cull(gfxSphere const& bounding_sphere, gfxFrustum const& frustum, gfxOutCode *ptr_outcode) 
{
   //bool checks
   bool insideOutsideCheck = false;
  *ptr_outcode = 0; 

  //loop with 6 as there is only 6 mplanes i never normalized
  //cause i normalized at calculated frustrum
  for (size_t i = 0; i < 6; ++i)
  {

	  const auto& frustumPlane = frustum.mPlanes[i];
	  gfxVector3 planeNormal{ frustumPlane.a, frustumPlane.b, frustumPlane.c };
	  float normalizedD = frustumPlane.d / planeNormal.Length();
	  planeNormal.Normalize();
	  float distanceCheck = bounding_sphere.center * planeNormal + normalizedD;
	  //perform a inside outside test for sphere center with respect to plane
	  //inside check
	  // nhat * c + d <= -r
	  if (distanceCheck <= -bounding_sphere.radius)
	  {
		  continue;
	  }
	  //outside check
	  // nhat * c + d > r
	  else if (distanceCheck > bounding_sphere.radius)
	  {
		  insideOutsideCheck = true;
	  }
	  //check if the plan intercept
	  // if -r < nhat * c + d < r
	  else
	  {
		  //bitshift by 1 bit 0001
		  *ptr_outcode |= (1 << i);
	  }

  }	
    
  return insideOutsideCheck;

}

/*  _________________________________________________________________________ */
gfxVertexBuffer YourClipper::
/*!
Perform clipping.

@param outcode	--> Outcode of view-frame of bounding sphere of object specifying
the view-frame frustum planes that the sphere is straddling.

@param vertex_buffer	--> The input vertex buffer contains three points 
forming a triangle.
Each vertex has x_c, y_c, z_c, and w_c fields that describe the position
of the vertex in clip space. Additionally, each vertex contains an array
of floats (bs[6]) that contains the boundary condition for each clip plane,
and an outcode value specifying which planes the vertex is inside.

The gfxClipPlane enum in GraphicsPipe.h contains the indices into bs
array. gfxClipCode contains bit values for each clip plane code.

If an object's bounding sphere could not be trivially accepted nor rejected,
it is reasonable to expect that the object is straddling only a
subset of the six frustum planes. This means that the object's triangles
need not be clipped against all the six frustum planes but only against
the subset of planes that the bounding sphere is straddling.
Furthermore, even if the bounding sphere is straddling a subset of planes,
the triangles themselves can be trivially accepted or rejected.
To implement the above two insights, use argument outcode - the object bounding
sphere's outcode which was previously returned by Cull().

Notes:
When computing clip frame intersection points, ensure that all necessary information
required to project and rasterize the vertex is computed using linear interpolation
between the inside and outside vertices. This includes:
clip frame coordinates: (c_x, c_y, c_z, c_w),
texture coordinates: (u, v),
vertex color coordinates: (r, g, b, a),
boundary conditions: bc[GFX_CPLEFT], bc[GFX_CPRIGHT], ...
outcode: oc

As explained in class, consistency in computing computing the parameter t
using t = 0 for inside point and t = 1 for outside point helps in preventing
tears and other artifacts.

Although the input primitive is a triangle, after clipping, the output
primitive may be a convex polygon with more than 3 vertices. In that
case, you must produce as output an ordered list of clipped vertices
that form triangles when taken in groups of three.

@return None
*/

/**
 * @brief Clip a triangle against a frustum's clipping region.
 * This function performs triangle clipping against the frustum's clipping region using the provided
 * @param outcode The output code indicating the frustum planes the triangle intersects.
 * The output code is a bitwise representation, with each bit corresponding to a frustum plane.
 * @param vertex_buffer The vertex buffer representing the triangle's vertices.
 * @return clipped triangle in camera view
 */
Clip(gfxOutCode outcode, gfxVertexBuffer const& vertex_buffer)
{

	// If the triangle is completely inside or outside the clipping region, return an empty vertex buffer
	if (outcode == 0)
	{
		return gfxVertexBuffer(vertex_buffer);
	}

	//create a temporary vertex buffer to store the output of the current clipping plane
	gfxVertexBuffer inputVertex = vertex_buffer;
	gfxVertexBuffer outputVertex{};

	//clip against each of the six clipping planes
	for (size_t i = 0; i < 6; ++i)
	{
		//edge procressing
		//clip each edge of the polygon against the current clipping plane
		for (size_t j = 0; j < inputVertex.size(); ++j)
		{
			size_t jOne = (j + 1) >= inputVertex.size() ? 0 : j + 1;
			gfxVertex p0 = inputVertex[j];
			gfxVertex p1 = inputVertex[jOne];

			//clip the edge based on the edge conditions and add the resulting vertex to the output buffer
			//rule 1 outside to inside
			if (p0.bc[i] > 0 && p1.bc[i] <= 0)
			{

				outputVertex.push_back(InterceptCalculation(p0, p1, i));
				outputVertex.push_back(p1);
			}
			//rule 2 both inside
			else if (p0.bc[i] <= 0 && p1.bc[i] <= 0)
			{
				outputVertex.push_back(p1);
			}
			//rule 3 inside to outside
			else if (p0.bc[i] <= 0 && p1.bc[i] > 0)
			{
				outputVertex.push_back(InterceptCalculation(p1, p0, i));
			}
		}

		//swap output to input so ican clear output
		inputVertex = outputVertex;
		outputVertex.clear();

	}

	//buffer to be push
	gfxVertexBuffer finalBuffer{};

	//triangulate the polygon by creating triangles from the vertice;
	if (inputVertex.size() == 0)
	{
		return gfxVertexBuffer();
	}
	else if (inputVertex.size() == 3)
	{
		return inputVertex;
	}
	else if (inputVertex.size() > 3)
	{
		for (size_t i = 2; i < inputVertex.size(); ++i)
		{
			finalBuffer.push_back(inputVertex[0]);
			finalBuffer.push_back(inputVertex[i - 1]);
			finalBuffer.push_back(inputVertex[i]);
		}
	}
	
	//return the final triangulated vertex buffer
	return finalBuffer;

}
/**
 * @brief Calculate the intersection point of a clipped edge with a frustum plane.
 * This function calculates the intersection point between a clipped edge defined by two vertices (p0 and p1) 
 * @param p0 The first vertex of the clipped edge, represented by a gfxVertex object.
 * @param p1 The second vertex of the clipped edge, represented by a gfxVertex object.
 * @param index The index of the frustum plane to which the clipped edge is intersecting.
 * @return A gfxVertex object representing the intersection point of the clipped edge with the frustum plane.
 * The gfxVertex object contains position, clip-space coordinates, texture coordinates, color, and barycentric coordinates
 * interpolated from the input vertices (p0 and p1) based on the t-value calculated from the barycentric coordinates.
 */
gfxVertex YourClipper::InterceptCalculation(gfxVertex p0, gfxVertex p1, unsigned int index)
{
	//get the t value
	float t = p0.bc[index] / (p0.bc[index] - p1.bc[index]);

	//to calculate my intersection value
	gfxVertex intersection{};

	//interpolate the intersection with t
	intersection.x_c = p0.x_c + (p1.x_c - p0.x_c) * t;
	intersection.y_c = p0.y_c + (p1.y_c - p0.y_c) * t;
	intersection.z_c = p0.z_c + (p1.z_c - p0.z_c) * t;
	intersection.w_c = p0.w_c + (p1.w_c - p0.w_c) * t;

	intersection.s = p0.s + (p1.s - p0.s) * t;
	intersection.t = p0.t + (p1.t - p0.t) * t;

	intersection.r = p0.r + (p1.r - p0.r) * t;
	intersection.g = p0.g + (p1.g - p0.g) * t;
	intersection.b = p0.b + (p1.b - p0.b) * t;
	intersection.a = p0.a + (p1.a - p0.a) * t;

	//update all the oc
	for (int i = 0; i < 6; ++i)
	{

		intersection.bc[i] = p0.bc[i] + (p1.bc[i] - p0.bc[i]) * t;
		if (intersection.bc[i] > 0)
		{
			intersection.oc |= 1 << i;
		}
	}

	return intersection;
}

	

