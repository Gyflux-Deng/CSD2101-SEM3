/*!
@file    Camera.cpp
@author  Prasanna Ghali  (pghali, pghali@digipen.edu)
@co-author maojie deng        (maojie.deng@digipen.edu)
@date 8/3/2023
CVS: $Id: Camera.cpp,v 1.13 2005/03/15 23:34:41 pghali Exp $

@brief 
Camera movement base off Spherical to Cartesian Coordinates
All content (c) 2005 DigiPen (USA) Corporation, all rights reserved.
*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */

#include "YourCamera.h"
#include <glm/glm.hpp>

/*                                                                  functions
----------------------------------------------------------------------------- */

/**
 * @brief displace the camera along its basis vectors.
 * The function displaces the camera such that it always follows the planar floor but can look up or down.
 * @param p Displacement along the camera's side x,y,z in vector3 format
 */
/*  _________________________________________________________________________ */
void YourCamera::
Move(gfxVector3 const& p)
/*! Displace the camera along its basis vectors.

    @param p -->  Displacement vector such that p.x, p.y, and p.z are
									displacements along the camera's side, up, and viewing
									basis vectors.
*/
{

/*	
	Displace the camera so that it is always following the planar floor but
	can look up or down. This behavior is unlike a flight simulator where the
	camera moves in the direction of the	view vector.
	Check out the sample application to make sure you understand the basic mechanics
	of the required camera.
*/
	
	
	Move(p.x, p.y, p.z);
}

/**
 * @brief displace the camera along its basis vectors.
 * The function displaces the camera such that it always follows the planar floor but can look up or down.
 * @param x Displacement along the camera's side x axis.
 * @param y Displacement along the camera's up y axis.
 * @param z Displacement along the camera's view -z axis.
 */
/*  _________________________________________________________________________ */
void YourCamera::
Move(float x, float y, float z)
/*! Displace the camera along its basis vectors.

    @param x -->  Displacement along camera's side (X) axis.
    @param y -->  Displacement along camera's up (Y) axis.
    @param z -->  Displacement along camera's view (-Z) axis.
*/
{
/*	
	Displace the camera such it is always following the planar floor but
	can look up or down. This behavior is unlike a flight simulator where the
	camera moves in the direction of the view vector.
	Check out the sample application to make sure you understand the basic mechanics
	of the required camera.
*/
	
	//get all the up eye tgt position
	gfxVector3 upGFX = GetUp();
	gfxVector3 eyeGFX = GetPosition();
	gfxVector3 tgtGFX = GetTarget();

	upGFX.Normalize();

	//set up the vector3 into glm vec3
	glm::vec3 up{ upGFX.x, upGFX.y, upGFX.z };
	glm::vec3 eye{ eyeGFX.x, eyeGFX.y, eyeGFX.z };
	glm::vec3 tgt{ tgtGFX.x, tgtGFX.y, tgtGFX.z };


	//compute view & side vector
	glm::vec3 View_Vector = glm::normalize(tgt - eye);
	glm::vec3 front{ View_Vector.x,0.f,View_Vector.z };
	glm::normalize(front);
	glm::vec3 right = glm::normalize(glm::cross(up, -front));
	
	//set the eye into it
	eye = eye + ( - right * x);
	eye = eye + (up * y);
	eye = eye + (front * z);

	tgt = tgt + ( - right * x);
	tgt = tgt + ( up * y);
	tgt = tgt + (front * z);

	//update the camera's target position
	SetPosition(gfxVector3(eye.x, eye.y, eye.z));
	SetTarget(gfxVector3(tgt.x, tgt.y, tgt.z));



}

/*  _________________________________________________________________________ */
/**
 * @brief Updates the camera's spherical coordinates using the 
 * updated camera position (mFrom) and camera target (mAt).
 * The function calculates the camera's spherical coordinates (latitude and azimuth) 
 * based on the updated camera position and target.
 */
void YourCamera::
UpdateSphericalFromPoints()
/*! Updates camera's spherical coordinates using updated
		camera position mFrom and camera target mAt.
*/
{
	//calculate the view vector 'View_Vector' as the difference between 
	//the camera's target position eye position.
	gfxVector3 upGFX = GetUp();
	gfxVector3 eyeGFX = GetPosition();
	gfxVector3 tgtGFX = GetTarget();

	glm::vec3 up{ upGFX.x, upGFX.y, upGFX.z };
	glm::vec3 eye{ eyeGFX.x, eyeGFX.y, eyeGFX.z };
	glm::vec3 tgt{ tgtGFX.x, tgtGFX.y, tgtGFX.z };

	glm::vec3 View_Vector = glm::normalize(tgt - eye);
		
	//calculate the camera's latitude angle based on the Y component of the normalized view vector.
	//this angle represents the angle of the view vector with the Y-Z plane, measured from the positive Y axis.
	
	mLatitude = asin(View_Vector.y);
	
	//calculate the camera's azimuth angle based on the x and z
	mAzimuth = (View_Vector.z != 0.f) ? atan2(View_Vector.x, View_Vector.z) :
		((View_Vector.x >= 0.f) ? (PI / 2.f) : ((3 * PI) / 2));	
}


/**
 * @brief Updates camera's target position mat using camera's updated spherical coordinates.
 * The function calculates the new target position mat of the camera based on the updated spherical coordinates (latitude and azimuth).
 * Then, the new 'mAt' position is updated as the sum of 'mFrom' and 'View_Vector'.
 */
/*  _________________________________________________________________________ */
void YourCamera::
UpdatePointsFromSpherical()
/*! Updates camera's target position mAt using camera's
		updated spherical coordinates.
*/
{
	//compute the view vector View_Vector from the spherical coordinates 
	float Latitude = GetLatitude();
	float Azimuth = GetAzimuth();
	//clamp value to prevent going out of [-1,1]
	float clampLatitude = fclamp(Latitude, -1.0f, 1.0f);

	gfxVector3 View_Vector
	{
		cos(clampLatitude) * sin(Azimuth),
		mRadius * sin(fclamp(clampLatitude, -1.f, 1.f)),
		mRadius * cos(clampLatitude) * cos(Azimuth)
	};
	//always normlized
	View_Vector.Normalize();

	//update the camera's target position
	mAt = mFrom + View_Vector;

}
