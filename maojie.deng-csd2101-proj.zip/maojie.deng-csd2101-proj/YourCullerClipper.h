/*!
@file    YourCullerClipper.h
@author  Prasanna Ghali       (pghali@digipen.edu)
@co-author maojie deng        (maojie.deng@digipen.edu)
@date 8/3/2023

@brief 
this is a header file for cullerclipper to hold the functions 

All content (c) 2002 DigiPen Institute of Technology, all rights reserved.
*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */

#ifndef YOUR_CULLER_CLIPPER_H_
#define YOUR_CULLER_CLIPPER_H_

/*                                                                   includes
----------------------------------------------------------------------------- */

#include "gfx/GFX.h"
#include <glm/glm.hpp>

/*                                                                    classes
----------------------------------------------------------------------------- */

/*  _________________________________________________________________________ */
class YourClipper : public gfxController_Clipping
/*! Example clipper subclass.

    This class implements culling (by bounding spheres) and clipping.
    You need to implement both the Cull() and the Clip() functions. More details
    can be found in the comments above each function.
*/
{
  public:
    // ct and dt
             YourClipper() { }
    virtual ~YourClipper() { }

		// operation - compute view-frame frustum
		virtual gfxFrustum ComputeFrustum(gfxMatrix4 const&	projection_mtx);

    // operations - culling
    virtual bool Cull(gfxSphere const&	bounding_sphere,
                      gfxFrustum const&	frustum,
                      gfxOutCode        *ptr_outcode);
    
    // operations - clipping
    virtual gfxVertexBuffer Clip(gfxOutCode outcode, gfxVertexBuffer const& vertex_buffer);
    //functions to calculated interception
    virtual gfxVertex InterceptCalculation(gfxVertex p0, gfxVertex p1, unsigned int index);
};

#endif  /* YOUR_CULLER_CLIPPER_H_ */
