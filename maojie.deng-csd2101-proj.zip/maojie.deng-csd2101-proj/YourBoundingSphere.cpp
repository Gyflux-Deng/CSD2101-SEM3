/*!
@file    BoundingSphere.cpp
@author  Prasanna Ghali   (pghali@digipen.edu)
@co-author Maojie.deng (maojie.deng@digipen.edu)
@date 8/3/2023
@brief

this is a bounding sphere cpp.The functions inside here calculates the bounding sphere model
using ritter's method.
it base off Based on the minimum and maximum values of each axis, 
it computes the diameter and radius of the bounding sphere. it also Using the maximum scale factor 
and the original radius of the bounding sphere, 
it computes the updated radius in the destination frame.


All content (c) 2002 DigiPen Institute of Technology, all rights reserved.
*//*__________________________________________________________________________*/

/*                                                                   includes
----------------------------------------------------------------------------- */

#include "gfx/GFX.h"
#include <limits>
#include <glm/glm.hpp>

/*  _________________________________________________________________________ */
/**
 * @brief calculate model's bounding sphere using Ritter's method.
 * This function computes the bounding sphere containing all the input vertices
 * stored in the verts vector using Ritter's method.
 * @param verts Model vertices of the scene object.
 * this function will be called once for each model as it is loaded.
 * @return Object of type gfxSphere defining the bounding
 * sphere containing the model using Ritter's method.
 */
gfxSphere gfxModel::
ComputeModelBVSphere(std::vector<gfxVector3> const& verts)
/*! Compute model's bounding sphere (in model frame) using Ritter's method.

    @param verts	-->	Model-frame vertices of scene object. This function will be
                      called once for each model as it is loaded. You should compute
                      the bounding sphere containing all the input vertices
                      stored in the verts vector using Ritter's method.
                      See GfxLib/Model.h, GfxLib/Sphere.h, GfxLib/Vertex.h for more
                      information regarding gfxModel, gfxSphere, and gfxVertex class
                      declarations.

    @return
    Object of type gfxSphere defining the bounding sphere containing the model using
    Ritter's method.
*/
{
    //initialise a min max value to 
    float pointXmin = std::numeric_limits<float>().max();
    float pointXmax = std::numeric_limits<float>().min();

    float pointYmin = std::numeric_limits<float>().max();
    float pointYmax = std::numeric_limits<float>().min();

    float pointZmin = std::numeric_limits<float>().max();
    float pointZmax = std::numeric_limits<float>().min();

    //forloop the whole thing and store the points into min and maxpoint
    //For each axis, compute two points
    //� Point containing minimum axis value
    //� Point containing maximum axis value
    for (const auto& vert : verts)
    {
        //check all min points
        if (vert.x < pointXmin)
        {
           pointXmin = vert.x;
        }
        if (vert.y < pointYmin)
        {
           pointYmin = vert.y;
        }
        if (vert.z < pointZmin)
        {
            pointZmin = vert.z;
        }

        //check all max points
        if (vert.x > pointXmax)
        {
           pointXmax = vert.x;
        }
        if (vert.y > pointYmax)
        {
           pointYmax = vert.y;

        }
        if (vert.z > pointZmax)
        {
           pointZmax = vert.z;
        }
    }

    ////Out of 3 pairs of points, 
    ////pick pair with maximum point-topoint 
    ////separation (distance)
    ////find the biggest value between all points x,y,z
    //Construct initial sphere using pair of points as diameter
    //find the biggest value between all points x,y,z
    float distanceX = pointXmax - pointXmin;

    float distanceY = pointYmax - pointYmin;

    float distanceZ = pointZmax - pointZmin;

    //then u find the maximumm distance and u put into the diameter
    float diameter = std::max(distanceX, std::max(distanceY, distanceZ));
    float radius = diameter * 0.5f;

    //center of point
    gfxVector3 cop{0.f,0.f,0.f};

    //check which one bigger and u take that value biggest dist
    //then u calculate base on that point to get cop
    if (distanceX >= distanceY && distanceX >= distanceZ)
    {
        cop.x = 0.5f * (pointXmin + pointXmax);
    }
    else if (distanceY >= distanceX && distanceY >= distanceZ)
    {
        cop.y = 0.5f * (pointYmin + pointYmax);
    }
    else
    {
        cop.z = 0.5f * (pointZmin + pointZmax);
    }

    //now calculate if the point is outside the bounding sphere
    // p outside bs <-> || P - C ||^2 > r^2
    for (const auto& points : verts)
    {
        float PminusCMagnitude = (points - cop).Length();
        float PminusCMagnitudeSquare = PminusCMagnitude * PminusCMagnitude;
        float r2 = radius * radius;

        if (PminusCMagnitudeSquare > r2)
        {
            //u normalized = p-c/||p-c||
            gfxVector3 uHat = (points - cop).Norm();
            //p` = C - r*uhat
            gfxVector3 pPrime = (cop - (radius * uHat));
            //new bounding sphere bs` 
            // center c` = p` + p / 2
            gfxVector3 cPrime = (0.5 * (pPrime + points));
            // radius r` = ||P - C`||
            float rPrime = (points - cPrime).Length();
            //return the new bounding sphere bs`
            return gfxSphere(cPrime.x, cPrime.y, cPrime.z, rPrime);
        }
    }

    //if no vertex was outside the bounding sphere
    return gfxSphere(cop.x, cop.y, cop.z, radius);


}

/*  _________________________________________________________________________ */

/**
 * @brief Transform a bounding sphere to a destination reference frame using 
 * the matrix manifestation of the transform from model to destination frame.
 * @param xform The matrix manifestation of the transform from model to destination frame.
 * @return The model bounding sphere transformed to the destination frame.
 */
gfxSphere gfxSphere::
Transform(gfxMatrix4 const& xform) const
/*! Transform a bounding sphere to a destination reference frame using
    the matrix manifestation of the transform from model to destination
    frame. Note that the only valid affine transforms for this assignment are:
    scale (if any), followed by rotation (if any), followed by translation.

    @param xform -->  The matrix manifestation of transform from model to
                      destination frame.

    @return
    The model bounding sphere transformed to destination frame.
*/
{
    //convert center to vec4 as u are using vec3
    gfxVector4 vec4Center{ center.x,center.y,center.z,1.0f };
    //get cw = Mm*Cm 
    // xform = Mm
    gfxVector4 Cw = xform * vec4Center;
    //to get Ci which i = 0,1,2 i need to get row
    gfxVector4 c0 = xform.GetCol4(0);
    gfxVector4 c1 = xform.GetCol4(1);
    gfxVector4 c2 = xform.GetCol4(2);
    //rw = rm * max {Ci which is 0,1,2,}
    float Rw = radius * std::max({ c0.Length(), c1.Length(), c2.Length() });
    //return the position of the updated position
    return gfxSphere(Cw.x, Cw.y, Cw.z, Rw);

}
    

