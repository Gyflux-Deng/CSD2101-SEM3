/*!
@file    glpbo.cpp
@author  Maojie.deng@digipen.edu
@date    7/19/2023
@brief
it is a GLPbo class is used to emulate graphics processing
and perform rendering operations using OpenGL.
The specific details of each member function's
functionality can be found in their respective implementations.

*//*__________________________________________________________________________*/
#include "glpbo.h"
//include the glhelper.h to allow glapp to use the functions written in glhelper
#include <glhelper.h>
//uses math to calculate graphic for linearly interpolating the color components.
#include "math.h"
//uses array library for me to access to array function
#include <array>
//uses iostream library for printing out data
#include <iostream>
//sstream to print out data ontop of the visual studio on top of the windows
#include <sstream>
#include <iomanip>
#include <fstream>
#include "glslshader.h"
#include "string"
#include <dpml.h>
#include <map>
#include <glm/gtc/matrix_transform.hpp>

/**
 * @namespace CORE10
 * @brief Namespace containing core settings for Assignment 2 - Core 10.
 */
namespace CORE10
{
	//6 core thing to put in here
	/*
		define and initialize static variable
		model file name
		texture file name
		camera position target
		six cliping plane
		light position
		light intensity
	*/
	//all this follow my glpbo class header file sequence
	//light intensity
	static glm::vec4 const lightIntesity{ 1.f,1.f,1.f,0.f };

	//light position
	static glm::vec4 const lightPosition{ 0.f,0.f,10.f,0.f};

	//light rotation speed
	static glm::vec2 const lightRotationspeed{ 0.f,30.f };

	//trigger for light rotation
	GLboolean lightRotating = GL_FALSE;

	//texture names
	static std::vector<std::string> const texName
	{
		"ogre"
	};

	//world transformation
	glm::vec3 eye = { 0.f,0.f,10.f }, tgt = { 0.f,0.f,0.f }, up = { 0.f,1.f,0.f };
	static const float left{ -1.5f },
		right{ 1.5f },
		bottom{ -1.5f },
		top{ 1.5f },
		near{ 8.f },
		far{ 12.f };

	//scaling matrix for objectss
	static const float ScalingMtx = { 2.f };

	//identity matrix for objects
	static const float identityMtx = { 1.f };

	//model names
	static std::vector<std::string> const modelName
	{
		"ogre",
		"cube"
	};

	//trigger for object rotation along the Y-axis
	GLboolean objRotationY = GL_FALSE;


}
//define 
#define PI 3.14159265358979323846f
#define UNREFERENCED_PARAMETER(P) (P)

//task 1  
/*
* Scan through the definition of type GLPbo and identify static data members. Begin your
* implementation by providing definitions to these static data members in glpbo.cpp .
*/
GLsizei GLPbo::width = 0;
GLsizei GLPbo::height = 0;
GLsizei GLPbo::pixel_cnt = 0; 
GLsizei GLPbo::byte_cnt = 0;
GLuint GLPbo::vaoid = 0;
GLuint GLPbo::elem_cnt = 0;
GLuint GLPbo::pboid = 0;
GLuint GLPbo::texid = 0;
GLPbo::Color* GLPbo::ptr_to_pbo = nullptr;
GLfloat* GLPbo::ptr_to_dbo = nullptr;
GLSLShader GLPbo::shdr_pgm{};
GLPbo::Color GLPbo::clear_clr{};

//assignment 1
//map to hold data from the obj file meshes
std::map<std::string, GLPbo::Model> GLPbo::meshes;
std::vector<std::string>GLPbo:: meshesData;
std::vector<std::string>::iterator GLPbo::dataIterator;

//data information for data print on bar
int vtxValue = 0;
int triValue = 0;
int cullValue = 0;

//assignment 2
GLPbo::PointLight pointLight;
GLPbo::TextureObj textureID;
GLfloat GLPbo::Rotation::rotationX;
GLfloat GLPbo::Rotation::rotationY;
GLfloat GLPbo::Rotation::rotationZ;
glm::vec3 GLPbo::Model::activeAxis = glm::vec3(0.0f);
glm::mat4 GLPbo::Triangle::ModelToWorld;

GLint fileSize{};
char* ptr_texels = nullptr;
GLubyte* ptr_texelColor = nullptr;

//for changing mode
std::vector<std::string> GLPbo::renderName
{
	"Wireframe",
	"Depth Buffer",
	"Faceted",
	"Shaded",
	"Textured",
	"Textured/Faceted",
	"Textured/Shaded"
};

/*
* @brief this function will be used by our graphics program to emulate the behaviors of vertex
* processor, rasterizer engine in graphics hardware, and fragment processor. This
* function will be called once per frame to write a color for every element in the PBO's
* data store (whose handle is GLPbo::pboid ) and then to transfer the entire data store's
* contents to the texture image storage (whose handle is GLPbo::texid ).
*/
void GLPbo::emulate()
{
	//set the screen color to white only 
	set_clear_color(0, 0, 0, 0);
	
	//Resetting the values
	vtxValue = 0;
	triValue = 0;
	cullValue = 0;

	//button functions
	buttonPress();
	
	//Part 3
	//Map the PBO data store's address (meaning the address of the data store's first
	//element) to client address space by calling glMapNamedBuffer and assigning the return
	//value to GLPbo::ptr_to_pbo.
	GLPbo::ptr_to_pbo = reinterpret_cast<GLPbo::Color*>(glMapNamedBuffer(GLPbo::pboid, GL_WRITE_ONLY));

	//Part 4
	//Call GLPbo::clear_color_buffer() to fill every pixel in the PBO's data store with the
	//color previously assigned to GLPbo::clear_color in step .
	GLPbo::clear_color_buffer();

	//Part 5
	//After GLPbo::clear_color_buffer() returns, release PBO's pointer in
	//GLPbo::ptr_to_pbo back to the graphics driver by calling glUnmapNamedBuffer .
	glUnmapNamedBuffer(GLPbo::pboid);

	//Part 6
	//Now, initialize the texture image with the PBO's data store by using
	//glTextureSubImage2D to DMA the image in PBO's data store to GLPbo::texid 's
	//texture image store.This is tricky - you'll need to carefully research GL commands
	//glTextureSubImage2D and glBindBuffer .
	//glBindTexture(GL_TEXTURE_2D, GLPbo::texid);
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER, GLPbo::pboid);
	glTextureSubImage2D(GLPbo::texid, 0, 0, 0, GLPbo::width, GLPbo::height, GL_RGBA, GL_UNSIGNED_BYTE, 0);
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
	glBindTexture(GL_TEXTURE_2D, 0);

	std::string selected_model = *dataIterator;

	viewport_xform(meshes[selected_model]);

	size_t meshVtx_list = meshes[selected_model].tris.size();


	//assignment2 
	GLPbo::Model::activeAxis = { GLPbo::Rotation::rotationX ,GLPbo::Rotation::Rotation::rotationY,GLPbo::Rotation::rotationZ };

	//if the list have more than 0 we the rendering
	if (meshVtx_list > 0)
	{
		static size_t counter = meshVtx_list;

		vtxValue = meshes[selected_model].pd.size();
		triValue = meshes[selected_model].tris.size() / 3;

		auto& posVtx_List = meshes[selected_model].posVtx_List;
		auto& mesh_pd = meshes[selected_model].pd;
		auto& mesh_nml = meshes[selected_model].nml;
		auto& mesh_tex = meshes[selected_model].tex;

		for (const Triangle& triangle : posVtx_List)
		{
			// Wireframe rendering
			if (*(meshes[selected_model].mode) == renderName[0])
			{
				if (!wireframe(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], GLPbo::Color{ 0, 0, 255, 0 }))
				{
					++cullValue;
				}
			}
			//depth shader
			else if (*(meshes[selected_model].mode) == renderName[1])
			{
				if (!GLPbo::Triangle::renderDepthbuffer(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			// Faceted rendering
			else if (*(meshes[selected_model].mode) == renderName[2])
			{
				if (!GLPbo::Triangle::renderTriangleFaceted(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			// Shaded rendering
			else if (*(meshes[selected_model].mode) == renderName[3])
			{
				if (!GLPbo::Triangle::renderTriangleShadedSmooth(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], mesh_nml[triangle.posIndex[0]], mesh_nml[triangle.posIndex[1]], mesh_nml[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			// Texture rendering
			else if (*(meshes[selected_model].mode) == renderName[4])
			{
				//std::cout << "mesh size : " << mesh_tex.size() << std::endl;

				if (!GLPbo::Triangle::renderTexture(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], mesh_tex[triangle.posIndex[0]], mesh_tex[triangle.posIndex[1]], mesh_tex[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			// Texture rendering Facted
			else if (*(meshes[selected_model].mode) == renderName[5])
			{
				//std::cout << "mesh size : " << mesh_tex.size() << std::endl;

				if (!GLPbo::Triangle::renderTextureFacted(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], mesh_tex[triangle.posIndex[0]], mesh_tex[triangle.posIndex[1]], mesh_tex[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			// Texture rendering Smooth
			else if (*(meshes[selected_model].mode) == renderName[6])
			{
				//std::cout << "mesh size : " << mesh_tex.size() << std::endl;

				if (!GLPbo::Triangle::renderTextureShadedSmooth(mesh_pd[triangle.posIndex[0]], mesh_pd[triangle.posIndex[1]], mesh_pd[triangle.posIndex[2]], 
					mesh_tex[triangle.posIndex[0]], mesh_tex[triangle.posIndex[1]], mesh_tex[triangle.posIndex[2]], 
					mesh_nml[triangle.posIndex[0]], mesh_nml[triangle.posIndex[1]], mesh_nml[triangle.posIndex[2]]))
				{
					++cullValue;
				}
			}
			
			
		}
	}

	//rotation
	if (CORE10::objRotationY)
	{
		meshes[selected_model].orientation.x += meshes[selected_model].orientation.y * static_cast<GLfloat>(GLHelper::delta_time);
	}	

	if (CORE10::lightRotating)
	{

		pointLight.lightOrientation.x = pointLight.lightOrientation.y * static_cast<GLfloat>(GLHelper::delta_time);
		//rotation angle in degrees
		float Rangle = glm::radians(pointLight.lightOrientation.x);
		pointLight.position = GLPbo::Rotation::rotationCalculation(pointLight.activeLightAxis.x, pointLight.activeLightAxis.y, pointLight.activeLightAxis.z, Rangle) * pointLight.position;
	}
}

/**
 * @brief draws a full-window quad using OpenGL.
 * this function sets up the necessary OpenGL state and draws a quad covering the entire window.
 * it binds a texture, selects a shader program, sets uniform values, and calls the necessary OpenGL functions to render the quad.
 * after completing the rendering, it resets the OpenGL state to its original state.
 */
void GLPbo::draw_fullwindow_quad()
{
	//set texture count
	glBindTextureUnit(6, GLPbo::texid);
	////bind texture
	//glBindTextureUnit(GL_TEXTURE_2D, GLPbo::texid);
	// there are many shader programs initialized - here we're saying
	// which specific shader program should be used to render geometry
	GLPbo::shdr_pgm.Use();
	//bind the vao for the whole window
	glBindVertexArray(GLPbo::vaoid);
	//call the shader
	shdr_pgm.SetUniform("Tex2d", 6);
	//draw triangle to form quad
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, NULL);
	//after completing the rendering, we tell the driver that VAO
	//vaoid and current shader program are no longer current
	//also gell texture no longer current too
	glBindVertexArray(0);

	glBindTexture(GL_TEXTURE_2D, 0);
	// after completing the rendering, we tell the driver that VAO
	// vaoid and current shader program are no longer current
	GLPbo::shdr_pgm.UnUse();
	//model name
	std::string modelName = *dataIterator;
	//u store the string into streamdata
	std::stringstream strData;
	//print out with the percision of setprecision
	strData << std::fixed << std::setprecision(2) << GLHelper::title << " | " << "Maojie Deng"  << 
		" | Model: " << modelName <<" | " 
		<< "Mode: " << *meshes[modelName].mode << " | "
		<< "Vertices: " << vtxValue << " | " 
		<< "Triangles: " << triValue << " | " 
		<< "Culled: " << cullValue << " | " << "FPS: " << GLHelper::fps;
	glfwSetWindowTitle(GLHelper::ptr_window, strData.str().c_str());

}

/**
 * @brief culls back-faces of a triangle using the CCW (Counter Clockwise) convention.
 * @param pos1 The coordinates of the first vertex of the triangle.
 * @param pos2 The coordinates of the second vertex of the triangle.
 * @param pos3 The coordinates of the third vertex of the triangle.
 * @return true if the triangle is not a back-face (CCW), false otherwise.
 */
bool GLPbo::Triangle::CullBackFacesCCW(glm::vec3 pos1, glm::vec3 pos2, glm::vec3 pos3)
{
	//calculate the cross product manually
	float crossProduct = (pos2.x - pos1.x) * (pos3.y - pos1.y) - (pos2.y - pos1.y) * (pos3.x - pos1.x);

	//if the cross product is positive, the triangle is facing towards the camera (CCW)
	//if the cross product is negative, the triangle is facing away from the camera (back-face)
	return crossProduct > 0.f;
}

/**
 * @brief renders the depth buffer for a triangle.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @return true if the rendering is successful, false otherwise.
 */
bool GLPbo::Triangle::renderDepthbuffer(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2)
{
	
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//calculates the interpolated depth value
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					//set depth value in the depth buffer for the pixel at the coordinates x,y
					setBuffer(x, y, depthZ);
					//calculate clr base on barycentric coordinates
					glm::vec3 clr{ (((hEval0)*p0) + ((hEval1)*p1) + ((hEval2)*p2)) * surfaceArea };
					//set pixel with clr value
					set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(clr.z * 255), static_cast<GLubyte>(clr.z * 255), static_cast<GLubyte>(clr.z * 255), 255));
				}
				
			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;

}

/**
 * @brief renders a faceted triangle by computing shading color for each pixel.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @return true if the triangle is successfully rendered, false otherwise.
 */
bool GLPbo::Triangle::renderTriangleFaceted(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2)
{
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	/*
	*   Compute shading color by evaluating the illumination model [see Equation ] at the
		triangle's centroid. Ensure vectors and in Equation are defined in the same coordinate
		system. Evaluating the illumination model in model frame provides the greatest efficiency
		since only the point light's position must be [inverse] transformed [once per object] from
		world frame to model frame rather than transforming a large count of triangle vertices from
		model frame to either world frame or view frame.
	*/

	//calculate  the model to world inverse
	glm::vec3 inverseP0 = inverseWorldCal(ModelToWorld, p0);
	glm::vec3 inverseP1 = inverseWorldCal(ModelToWorld, p1);
	glm::vec3 inverseP2 = inverseWorldCal(ModelToWorld, p2);

	//calculate center of the triangle 
	//centroid = (vertex1 + vertex2 + vertex3) / 3
	glm::vec3 centroid = (inverseP0 + inverseP1 + inverseP2) / 3.f;

	//calculate the normal of triangle from the inverse
	glm::vec3 inversedNormal = calculateTriangleNormal(inverseP0, inverseP1, inverseP2);

	//color for the object
	glm::vec3 diffuser{ 255,255,255};
	//function computes the lighting 
	glm::vec3 objColor = GLPbo::PointLight::calculateLighting(pointLight.position, centroid, inversedNormal, pointLight.intensity, diffuser);
	

	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//calculates the interpolated depth value
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					//set depth value in the depth buffer for the pixel at the coordinates x,y
					setBuffer(x, y, depthZ);
					//set pixel with obj color from point light value value
					set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(objColor.x), static_cast<GLubyte>(objColor.y), static_cast<GLubyte>(objColor.z), 255));
				}
				
			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;

}

/**
 * @brief renders a shaded smooth triangle by computing shading color for each pixel.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param pnml0 The normal at vertex p0.
 * @param pnml1 The normal at vertex p1.
 * @param pnml2 The normal at vertex p2.
 * @return true if the triangle is successfully rendered, false otherwise.
 */
bool GLPbo::Triangle::renderTriangleShadedSmooth(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec3 pnml0, glm::vec3 pnml1, glm::vec3 pnml2)
{
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	/*
	*   Compute shading color by evaluating the illumination model [see Equation ] at the
		triangle's centroid. Ensure vectors and in Equation are defined in the same coordinate
		system. Evaluating the illumination model in model frame provides the greatest efficiency
		since only the point light's position must be [inverse] transformed [once per object] from
		world frame to model frame rather than transforming a large count of triangle vertices from
		model frame to either world frame or view frame.
	*/

	//calculate  the model to world inverse
	glm::vec3 inverseP0 = inverseWorldCal(ModelToWorld, p0);
	glm::vec3 inverseP1 = inverseWorldCal(ModelToWorld, p1);
	glm::vec3 inverseP2 = inverseWorldCal(ModelToWorld, p2);

	//calculating shading color for each vertex
	glm::vec3 diffuser{ 255,255,255 };
	glm::vec3 objColorX = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP0,pnml0, pointLight.intensity, diffuser);
	glm::vec3 objColorY = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP1, pnml1, pointLight.intensity, diffuser);
	glm::vec3 objColorZ = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP2, pnml2, pointLight.intensity, diffuser);


	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//calculates the interpolated depth value
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					//set depth value in the depth buffer for the pixel at the coordinates x,y
					setBuffer(x, y, depthZ);
					//calculate the interpolated color using the shading color values
					glm::vec3 clr{ (((hEval0)*objColorX) + ((hEval1)*objColorY) + ((hEval2)*objColorZ)) * surfaceArea };
					// Set the pixel color with the interpolated color
					set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(clr.x), static_cast<GLubyte>(clr.y), static_cast<GLubyte>(clr.z), 255));
				}

			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;

}

/**
 * @brief renders a textured triangle by mapping texture coordinates to each pixel.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param uv0 The texture coordinate at vertex p0.
 * @param uv1 The texture coordinate at vertex p1.
 * @param uv2 The texture coordinate at vertex p2.
 * @return true if the triangle is successfully rendered, false otherwise.
 */
bool GLPbo::Triangle::renderTexture(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec2 uv0, glm::vec2 uv1, glm::vec2 uv2)
{
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	/*
	*   Compute shading color by evaluating the illumination model [see Equation ] at the
		triangle's centroid. Ensure vectors and in Equation are defined in the same coordinate
		system. Evaluating the illumination model in model frame provides the greatest efficiency
		since only the point light's position must be [inverse] transformed [once per object] from
		world frame to model frame rather than transforming a large count of triangle vertices from
		model frame to either world frame or view frame.
	*/

	//calculate  the model to world inverse
	glm::vec3 inverseP0 = inverseWorldCal(ModelToWorld, p0);
	glm::vec3 inverseP1 = inverseWorldCal(ModelToWorld, p1);
	glm::vec3 inverseP2 = inverseWorldCal(ModelToWorld, p2);

	
	
	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//calculates the interpolated depth value
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					//set depth value in the depth buffer for the pixel at the coordinates x,y
					setBuffer(x, y, depthZ);
					//compute texture coordinates at the pixel using barycentric interpolation
					glm::vec2 uv = ((hEval0 * uv0) + (hEval1 * uv1) + (hEval2 * uv2)) * surfaceArea;
					//compute texel coordinates based on the texture ID
					glm::vec2 texelCoords = glm::vec2(uv * glm::vec2(textureID.x, textureID.y));
					//retrieve the texel color from the texture object
					glm::vec3 texelColor = GLPbo::TextureObj::getTexelColor(static_cast<int>(texelCoords.x), static_cast<int>(texelCoords.y));
					//set the pixel color with the texel color
					set_pixel(x, y, GLPbo::Color(static_cast<GLubyte>(texelColor.x), static_cast<GLubyte>(texelColor.y), static_cast<GLubyte>(texelColor.z), 255));
				}

			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;

}

/**
 * @brief renders a faceted textured triangle by mapping texture coordinates to each pixel.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param uv0 The texture coordinate at vertex p0.
 * @param uv1 The texture coordinate at vertex p1.
 * @param uv2 The texture coordinate at vertex p2.
 * @return true if the triangle is successfully rendered, false otherwise.
 */
bool GLPbo::Triangle::renderTextureFacted(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec2 uv0, glm::vec2 uv1, glm::vec2 uv2)
{
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	//compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	//evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	//compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	//calculate  the model to world inverse
	glm::vec3 inverseP0 = inverseWorldCal(ModelToWorld, p0);
	glm::vec3 inverseP1 = inverseWorldCal(ModelToWorld, p1);
	glm::vec3 inverseP2 = inverseWorldCal(ModelToWorld, p2);

	//calculate center of the triangle 
	//centroid = (vertex1 + vertex2 + vertex3) / 3
	glm::vec3 centroid = (inverseP0 + inverseP1 + inverseP2) / 3.f;

	//calculate the normal of triangle from the inverse
	glm::vec3 inversedNormal = calculateTriangleNormal(inverseP0, inverseP1, inverseP2);

	

	for (int y = ymin; y < ymax; ++y)
	{
		//sart values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				//calculates the interpolated depth value
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					//set depth value in the depth buffer for the pixel at the coordinates x,y
					setBuffer(x, y, depthZ);
					//compute texture coordinates at the pixel using barycentric interpolation
					glm::vec2 uv = ((hEval0 * uv0) + (hEval1 * uv1) + (hEval2 * uv2)) * surfaceArea;
					// Retrieve texel color from texture
					glm::vec3 texelColor = TextureObj::getTexelColor(static_cast<int>(uv.x * textureID.x), static_cast<int>(uv.y * textureID.y));
					//set the pixel color with the texel color
					glm::vec3 objColor = GLPbo::PointLight::calculateLighting(pointLight.position, centroid, inversedNormal, pointLight.intensity, texelColor);
					// Set the pixel color in the frame buffer
					set_pixel(x, y, Color(static_cast<GLubyte>(objColor.r), static_cast<GLubyte>(objColor.g), static_cast<GLubyte>(objColor.b), 255));
				}
			}

			//incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		//incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;
}

/**
 * @brief sRenders a smoothly shaded textured triangle by mapping texture coordinates to each pixel
 * and calculating the shading color using a lighting model.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param uv0 The texture coordinate at vertex p0.
 * @param uv1 The texture coordinate at vertex p1.
 * @param uv2 The texture coordinate at vertex p2.
 * @param pnml0 The vertex normal at vertex p0.
 * @param pnml1 The vertex normal at vertex p1.
 * @param pnml2 The vertex normal at vertex p2.
 * @return true if the triangle is successfully rendered, false otherwise.
 */
bool GLPbo::Triangle::renderTextureShadedSmooth(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, glm::vec2 uv0, glm::vec2 uv1, glm::vec2 uv2, glm::vec3 pnml0, glm::vec3 pnml1, glm::vec3 pnml2)
{
	// Check culling
	if (!CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	// Compute the axis-aligned bounding box (AABB) for the triangle
	int xmin = std::min({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) });
	int xmax = std::max({ static_cast<int>(p0.x), static_cast<int>(p1.x), static_cast<int>(p2.x) }) + 1;
	int ymin = std::min({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) });
	int ymax = std::max({ static_cast<int>(p0.y), static_cast<int>(p1.y), static_cast<int>(p2.y) }) + 1;

	// Compute the surface area of the triangle
	float surfaceArea = 1.0f / ((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y));

	// Evaluate the edge equations at the starting point of the AABB
	glm::vec3 pointSample(xmin + 0.5f, ymin + 0.5f, 0.0f);
	glm::vec3 edge0 = edgeEquation(p1, p2);
	glm::vec3 edge1 = edgeEquation(p2, p0);
	glm::vec3 edge2 = edgeEquation(p0, p1);

	float Eval0 = edge0.x * pointSample.x + edge0.y * pointSample.y + edge0.z;
	float Eval1 = edge1.x * pointSample.x + edge1.y * pointSample.y + edge1.z;
	float Eval2 = edge2.x * pointSample.x + edge2.y * pointSample.y + edge2.z;

	// Compute the edge increments
	float edge0XInc = edge0.x;
	float edge1XInc = edge1.x;
	float edge2XInc = edge2.x;
	float edge0YInc = edge0.y;
	float edge1YInc = edge1.y;
	float edge2YInc = edge2.y;

	bool t1 = (edge0.x != 0.0f) ? (edge0.x > 0.0f) : (edge0.y < 0.0f);
	bool t2 = (edge1.x != 0.0f) ? (edge1.x > 0.0f) : (edge1.y < 0.0f);
	bool t3 = (edge2.x != 0.0f) ? (edge2.x > 0.0f) : (edge2.y < 0.0f);

	// Calculate the model to world inverse
	glm::vec3 inverseP0 = inverseWorldCal(ModelToWorld, p0);
	glm::vec3 inverseP1 = inverseWorldCal(ModelToWorld, p1);
	glm::vec3 inverseP2 = inverseWorldCal(ModelToWorld, p2);

	for (int y = ymin; y < ymax; ++y)
	{
		// Start values for horizontal spans
		float hEval0 = Eval0;
		float hEval1 = Eval1;
		float hEval2 = Eval2;

		for (int x = xmin; x < xmax; ++x)
		{
			if (PointInEdgeTopLeft(hEval0, t1) && PointInEdgeTopLeft(hEval1, t2) && PointInEdgeTopLeft(hEval2, t3))
			{
				float depthZ = ((hEval0 * p0.z) + (hEval1 * p1.z) + (hEval2 * p2.z)) * surfaceArea;
				if (depthZ < getBuffer(x, y))
				{
					setBuffer(x, y, depthZ);

					//compute texture coordinates at the pixel using barycentric interpolation
					glm::vec2 uv = ((hEval0 * uv0) + (hEval1 * uv1) + (hEval2 * uv2)) * surfaceArea;
					//retrieve texel color from texture
					glm::vec3 texelColor = TextureObj::getTexelColor(static_cast<int>(uv.x * textureID.x), static_cast<int>(uv.y * textureID.y));

					//calculate shading color using smooth shading and lighting model
					glm::vec3 objColorX = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP0, pnml0, pointLight.intensity, texelColor);
					glm::vec3 objColorY = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP1, pnml1, pointLight.intensity, texelColor);
					glm::vec3 objColorZ = GLPbo::PointLight::calculateLighting(pointLight.position, inverseP2, pnml2, pointLight.intensity, texelColor);
					glm::vec3 objColor = (((hEval0 * objColorX) + (hEval1 * objColorY) + (hEval2 * objColorZ)) * surfaceArea);

					//set the pixel color in the frame buffer
					set_pixel(x, y, Color(static_cast<GLubyte>(objColor.r), static_cast<GLubyte>(objColor.g), static_cast<GLubyte>(objColor.b), 255));
				}
			}

			// Incrementally update hEval0, hEval1, hEval2
			hEval0 += edge0XInc;
			hEval1 += edge1XInc;
			hEval2 += edge2XInc;
		}

		// Incrementally update Eval0, Eval1, Eval2
		Eval0 += edge0YInc;
		Eval1 += edge1YInc;
		Eval2 += edge2YInc;
	}

	return true;
}

/**
 * @brief applies viewport transformation to the vertices of a model.
 * @param mdl The model whose vertices will be transformed.
 */
void GLPbo::viewport_xform(GLPbo::Model& mdl)
{
	
	//local variable 
	//assignment 2 camera viewport improvements
	float aespectration = (float)GLHelper::width / (float)GLHelper::height;

	//rotation angle in degrees
	float Rangle = glm::radians(mdl.orientation.x);

	glm::mat4 view_transform = glm::lookAt(CORE10::eye,CORE10::tgt,CORE10::up);

	glm::mat4 proj_xform = glm::ortho((CORE10::left * aespectration),(CORE10::right * aespectration), CORE10::bottom, CORE10::top, CORE10::near, CORE10::far);

	//assignment 2 rotation matrix by its own axis 
	glm::vec3 normalizedAxis{ glm::normalize(mdl.activeAxis) };

	//calculate everything in this functiosn i pass in normalized and radian
	glm::mat4 finalCalculated = GLPbo::Rotation::rotationCalculation(normalizedAxis.x,normalizedAxis.y,normalizedAxis.z, Rangle);
	//set to 1 as the scaling and identiy cause it to be not 1
	finalCalculated[3][3] = 1;

	//scale matrix of 2
	glm::mat4 scaleMatrix
	{
		CORE10::ScalingMtx, 0.0f, 0.0f, 0.0f,
		0.0f, CORE10::ScalingMtx, 0.0f, 0.0f,
		0.0f, 0.0f, CORE10::ScalingMtx, 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f
	};

	//create the viewport matrix
	glm::mat4 ndc_to_viewport
	{
		(GLHelper::width / 2.f), 0, 0, 0,
		0, (GLHelper::height / 2.f), 0, 0,
		0, 0, 0.5f, 0,
		(GLHelper::width / 2.f), (GLHelper::height / 2.f), 0.5f, 1
	};

	mdl.pd = mdl.pm;
	glm::mat4 viewportProjectionViewTransform = ndc_to_viewport * proj_xform * view_transform;
	glm::mat4 finalModelTransformation = finalCalculated * scaleMatrix;

	//put the model pd into transform
	for (auto& modelVtx : mdl.pd)
	{
		glm::vec4 temp{ modelVtx.x, modelVtx.y,modelVtx.z,1 };
		glm::vec4 calculatedAffine{ viewportProjectionViewTransform * finalModelTransformation * temp };
		modelVtx = glm::vec3{ calculatedAffine.x, calculatedAffine.y,calculatedAffine.z };	
	}
	//store my model to world setting
	GLPbo::Triangle::ModelToWorld = viewportProjectionViewTransform;
}

/**
 * @brief writes the specified color at the given window coordinates in the PBO buffer,
 * taking into account scissoring with the entire window as the scissor rectangle.
 * @param x The x-coordinate of the pixel.
 * @param y The y-coordinate of the pixel.
 * @param clr The color to be written at the pixel.
 */
void GLPbo::set_pixel(GLint x, GLint y, GLPbo::Color clr)
{
	//perform scissoring with the entire window as the scissor rectangle
	if (x < 0 || x >= GLHelper::width || y < 0 || y >= GLHelper::height)
	{
		//pixel is outside the scissor rectangle, skip writing
		return;  
	}

	//calculate the index of the pixel in the PBO buffer
	GLPbo::Color* pixel_ptr = ptr_to_pbo + (GLHelper::width * y) + x;

	//write the color at the pixel location
	*pixel_ptr = clr;
}

/**
 * @brief sets the value of a pixel in the buffer at the specified position.
 * @param x The x-coordinate of the pixel.
 * @param y The y-coordinate of the pixel.
 * @param bufferValue The value to set in the buffer.
 */
void GLPbo::setBuffer(GLint x, GLint y, GLfloat bufferValue)
{
	//perform scissoring with the entire window as the scissor rectangle
	if (x < 0 || x >= GLHelper::width || y < 0 || y >= GLHelper::height)
	{
		//pixel is outside the scissor rectangle, skip writing
		return;
	}

	//calculate the index of the pixel in the PBO buffer
	*(ptr_to_dbo + (GLHelper::width * y) + x) = bufferValue;

}

/**
 * @brief retrieves the value of a pixel from the buffer at the specified position.
 * @param x The x-coordinate of the pixel.
 * @param y The y-coordinate of the pixel.
 * @return The value of the pixel in the buffer.
 */
GLfloat GLPbo::getBuffer(GLint x, GLint y)
{
	//perform scissoring with the entire window as the scissor rectangle
	if (x < 0 || x >= GLHelper::width || y < 0 || y >= GLHelper::height)
	{
		//pixel is outside the scissor rectangle, skip writing
		return 1;
	}

	//calculate the index of the pixel in the DBO buffer
	return *(ptr_to_dbo + (GLHelper::width * y) + x);

}

/**
 * @brief handles button press events.
 */
void GLPbo::buttonPress()
{
	//button press for changing object
	if (GLHelper::keystateM)
	{
		//increment the data iterator and wrap around if necessary
		if (++dataIterator == meshesData.end())
		{
			dataIterator = meshesData.begin();
		}
		GLHelper::keystateM = GL_FALSE;
		CORE10::objRotationY = GL_FALSE;
	}

	//change mode
	if (GLHelper::keystateW)
	{
		//get the selected mesh and increment its mode, wrapping around if necessary
		std::string selected_mesh = *dataIterator;
		if (++meshes[selected_mesh].mode == renderName.end())
		{
			meshes[selected_mesh].mode = renderName.begin();
		}
		GLHelper::keystateW = GL_FALSE;
	}

	//rotate y axis
	if (GLHelper::keystateR)
	{
		//toggle the objRotationY flag
		GLHelper::keystateR = GL_FALSE;
		CORE10::objRotationY = (CORE10::objRotationY) ? GL_FALSE : GL_TRUE;
	}

	//rotate x axis
	if (GLHelper::keystateX)
	{
		//toggle the objRotationX flag
		GLPbo::Rotation::rotationX = (GLPbo::Rotation::rotationX == 1.f) ? 0.f : 1.f;
		GLHelper::keystateX = GL_FALSE;
	}

	//rotate z axis
	if (GLHelper::keystateZ)
	{
		//toggle the objRotationZ flag
		GLPbo::Rotation::rotationZ = (GLPbo::Rotation::rotationZ == 1.f) ? 0.f : 1.f;
		GLHelper::keystateZ = GL_FALSE;
	}

	//rotate light at y axis
	if (GLHelper::keystateL)
	{
		GLHelper::keystateL = GL_FALSE;
		CORE10::lightRotating = (CORE10::lightRotating) ? GL_FALSE : GL_TRUE;
	}
}

/**
 *@brief renders a line using the Bresenham algorithm in the specified octant.
 *This function renders a line segment between two points using the Bresenham algorithm.
 *The algorithm used depends on the value of the bresenham1256 parameter.
 *@param px0 The x-coordinate of the starting point.
 *@param py0 The y-coordinate of the starting point.
 *@param px1 The x-coordinate of the ending point.
 *@param py1 The y-coordinate of the ending point.
 *@param draw_clr The color of the line to be rendered.
*/
void GLPbo::render_linebresenham(GLint px0, GLint py0, GLint px1, GLint py1, GLPbo::Color draw_clr)
{
	////for octian 0 3 4 7
	GLint dx = px1 - px0;
	GLint dy = py1 - py0;

	////determine the step directions for x and y
	int xstep = (dx < 0) ? -1 : 1;
	int ystep = (dy < 0) ? -1 : 1;

	////take absolute values of dx and dy
	dx = (dx < 0) ? -dx : dx;
	dy = (dy < 0) ? -dy : dy;

	////renders a line using Bresenham's line drawing algorithm for octants 1, 2, 5, and 6.
	if (dy <= dx)
	{
		//calculate decision variable and error adjustments
		int d = 2 * dy - dx;
		int dmin = 2 * dy;
		int dmaj = 2 * dy - 2 * dx;
		//set the initial pixel
		set_pixel(px0, py0, draw_clr);
		//iterate through the pixels along the line x
		while (--dx > 0)
		{
			//update y coordinate based on decision variable
			py0 += (d > 0) ? ystep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			px0 += xstep;
			//set the pixel
			set_pixel(px0, py0, draw_clr);
		}
	}
	else
	{
		//calculate decision variable and error adjustments
		int d = 2 * dx - dy;
		int dmin = 2 * dx;
		int dmaj = 2 * dx - 2 * dy;
		//set the initial pixel
		set_pixel(px0, py0, draw_clr);
		//iterate through the pixels along the line y
		while (--dy > 0)
		{
			//update y coordinate based on decision variable
			px0 += (d > 0) ? xstep : 0;
			//update decision variable and error adjustments
			d += (d > 0) ? dmaj : dmin;
			//update x coordinate
			py0 += ystep;
			//set the pixel
			set_pixel(px0, py0, draw_clr);
		}
	}
	
}

/**
 * @brief draws a wireframe triangle using Bresenham's line algorithm.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @param clr The color of the wireframe.
 * @return true if the wireframe was successfully rendered, false otherwise.
 */
bool GLPbo::wireframe(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2, GLPbo::Color clr)
{
	//check if back faces should be culled
	if (!GLPbo::Triangle::CullBackFacesCCW(p0, p1, p2))
	{
		return false;
	}

	//render lines using Bresenham's line algorithm
	render_linebresenham(static_cast<GLint>(p0.x), static_cast<GLint>(p0.y), static_cast<GLint>(p1.x), static_cast<GLint>(p1.y), clr);
	render_linebresenham(static_cast<GLint>(p1.x), static_cast<GLint>(p1.y), static_cast<GLint>(p2.x), static_cast<GLint>(p2.y), clr);
	render_linebresenham(static_cast<GLint>(p2.x), static_cast<GLint>(p2.y), static_cast<GLint>(p0.x), static_cast<GLint>(p0.y), clr);

	return true;
}

/**
 *@brief checks if a point is in the top-left region defined by an edge equation.
 *@param edge the coefficients of the edge equation in the form of a 3D vector.
 *@param point the coordinates of the point to be checked in the form of a 3D vector.
 *@return true if the point is in the top-left region, false otherwise.
 */
bool GLPbo::Triangle::PointInEdgeTopLeft(float eval, bool tl)
{

	return(eval > 0.f || (eval == 0.f && tl)) ? true : false;
}

/**
 * @brief calculates the coefficients of the edge equation given two points on the edge.
 * @param p1 the coordinates of the first point on the edge.
 * @param p2 tthe coordinates of the second point on the edge.
 * @return the edge equation coefficients as a 3D vector (a, b, c) where ax + by + c = 0.
 */
glm::vec3 GLPbo::Triangle::edgeEquation(glm::vec3 p0, glm::vec3 p1)
{
	//calculate the coefficients of the edge equation
	float pointA = p0.y - p1.y;
	float pointB = p1.x - p0.x;
	float pointC = (p0.x * (p1.y - p0.y)) - (p0.y *(p1.x - p0.x));

	//return the edge equation coefficients as a 3D vector
	return glm::vec3(pointA, pointB, pointC);
}

/**
 * @brief generates a random floating-point number between 0 and 1.
 * @return random float value between 0 and 1.
 */
float GLPbo::rand_float()
{
	return static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
}

/**
 * @brief initializes the GLPbo object with the specified width and height.
 * this function initializes the GLPbo object by setting values for various data members and creating necessary OpenGL objects.
 * it assigns the width and height values to the static data members GLPbo::width and GLPbo::height.
 * it calculates the pixel count and byte count based on the width and height.
 * it sets the PBO fill color and creates a texture object and a PBO using the specified steps.
 * it also sets up the vertex array object and initializes the shader object.
 * @param w The width
 * @param h The height
 */
void GLPbo::init(GLsizei w, GLsizei h)
{
	//assignnment 1
	//read obj file when i init
	for (auto const& texName : CORE10::texName)
	{
		GLPbo::TextureObj::init_texture(texName);
	}
	for (auto const& Modelname : CORE10::modelName)
	{
		init_scene(Modelname);

	}
	
	//init the pointlight data here
	pointLight.intensity = CORE10::lightIntesity;
	pointLight.position = CORE10::lightPosition;
	pointLight.lightOrientation = CORE10::lightRotationspeed;
	pointLight.activeLightAxis = { 0.f,1.f,0.f };

	//assignmen 2
	//init the rotation value 
	GLPbo::Rotation::rotationX = 0;
	GLPbo::Rotation::rotationY = 1;
	GLPbo::Rotation::rotationZ = 0;
	GLPbo::Model::activeAxis ={ GLPbo::Rotation::rotationX ,GLPbo::Rotation::rotationY,GLPbo::Rotation::rotationZ };

	//Part 3
	/*
	 *Begin by assigning appropriate values to static data members GLPbo::width ,
	 *GLPbo::height , GLPbo::pixel_cnt , and GLPbo::byte_cnt :	
	*/
	width = w;
	height = h;
	//pixel_cnt = width * height
	pixel_cnt = width * height;
	//Data member GLPbo::byte_cnt specifies the size in bytes of the PBO's data store
	//(and texture image) and should therefore be equivalent to pixel_cnt * 4
	byte_cnt = pixel_cnt * 4;
	//Part 4
	//Set the PBO fill color (to white or whatever other color you wish) 
	set_clear_color(0, 0, 0, 0);

	//Part 5
	//Create a texture object with storage for a texture image that is exactly equivalent to the
	//size of the PBO's data store. 
	glCreateTextures(GL_TEXTURE_2D,1, &texid);
	glTextureStorage2D(texid, 1, GL_RGBA8, width, height);
	
	//Part 6
	//Create a PBO using the steps described here.
	glCreateBuffers(1, &pboid);
	glNamedBufferStorage(pboid,byte_cnt,nullptr,GL_DYNAMIC_STORAGE_BIT | GL_MAP_WRITE_BIT);

	//assignment 2 
	//creating a new depth buffer to store
	ptr_to_dbo = new GLfloat[pixel_cnt];

	//assignment 1 

	//Part 7
	//To render the texture image created from the colors written into the PBO's data store,
	//data member
	setup_quad_vao();
	//Part 8
	//you'll need to initialize the shader object GLPbo::shdr_pgm that will contain the
	//shader program that will render the texture mapped full - screen quad.
	setup_shdrpgm();

}

/**
 * @brief initializes the scene based on the specified scene file.
 * @param scene_filename the filename of the scene file to be loaded.
 */
void GLPbo::init_scene(std::string scene_filename)
{

		//check the whole file from the start till the end
		//get the string name 
		std::string model_line{scene_filename};
		//create gameobject 
		Model gO;
		size_t numTriangles{};
		//check if the string name is empty
		if (!model_line.empty() && !meshes.contains(model_line))
		{
			//read mesh file
			std::string meshFile{ "../meshes/" };
			std::string fileData{ meshFile + model_line + ".obj" };
			if (!DPML::parse_obj_mesh(fileData, gO.pm, gO.nml, gO.tex, gO.tris, true, true))
			{
				std::cout << "Object file cannot be loaded " << model_line << "\n";
			}
			else
			{

				//calculate the number of triangles based on the size of the vertex array divided by 3
				numTriangles = gO.tris.size() / 3;

				//iterate over each triangle
				for (size_t i = 0; i < numTriangles; ++i)
				{
					//calculate the starting index of the current triangle
					size_t index = i * 3;

					//extract the vertex indices for the current triangle
					unsigned short index0 = gO.tris[index];
					unsigned short index1 = gO.tris[index + 1];
					unsigned short index2 = gO.tris[index + 2];


					gO.mode = GLPbo::renderName.begin();

					//create a new triangle object using the extracted indices and add it to the posVtx_List
					gO.posVtx_List.emplace_back(GLPbo::Triangle{ index0, index1, index2
						,glm::vec3(rand_float(), rand_float(), rand_float()),
						 glm::vec3(rand_float(), rand_float(), rand_float()),
						 glm::vec3(rand_float(), rand_float(), rand_float()) });
				}


			}
		}
		//pushback into the map
		meshes.emplace(model_line, gO);

		//pushback data into vector array
		meshesData.push_back(model_line);

		//print out data as the same as console
		std::cout << "Model: " << model_line << std::endl;
		std::cout << "Vertex position count: " << gO.pm.size() << std::endl;
		std::cout << "Vertex texture  count: " << gO.tex.size() << std::endl;
		std::cout << "Vertex normal   count: " << gO.nml.size() << std::endl;
		std::cout << "Triangle        count: " << numTriangles << std::endl;

		dataIterator = meshesData.begin();


	

}

/**
 * @brief initializes the texture object with the specified texture file.
 * @param texture The name of the texture file.
 */
void GLPbo::TextureObj::init_texture(std::string texture)
{
	//read file
	std::string texFilePath = "../images/" + texture + ".tex";
	std::ifstream ifs(texFilePath, std::ios_base::in | std::ios::binary);
	if (!ifs)
	{
		std::cout << "ERROR: Unable to open texture file: " << texture << "\n";
		exit(EXIT_FAILURE);
	}
	//read texture file header
	ifs.seekg(0, std::ios::beg);
	ifs.read(reinterpret_cast<char*> (&textureID.x), sizeof(int));
	ifs.read(reinterpret_cast<char*> (&textureID.y), sizeof(int));
	ifs.read(reinterpret_cast<char*> (&textureID.bytes), sizeof(int));

	//calculate the texture data of the image
	fileSize = textureID.x * textureID.y * textureID.bytes;

	ptr_texels = new char[fileSize];

	//read texture data
	ifs.read(ptr_texels, fileSize);

	//print out data as the same as console
	std::cout << "Loaded image " << texture << ":" << std::endl;
	std::cout << "Image width: " << textureID.x << std::endl;
	std::cout << "Image height: " << textureID.y << std::endl;
	std::cout << "Image BPP   : " << textureID.bytes << std::endl;

	//close file
	ifs.close();

	

}

/**
 * @brief sets up the vertex array object (VAO) for rendering a quad in normalized device coordinates (NDC).
 * this function defines the positions and texture coordinates of the vertices that form a quad in the 2D plane.
 * it creates a buffer object to store the vertex data and copies the position and texture coordinate data to the buffer.
 * it then creates a VAO and sets up the vertex attribute state, enabling the necessary vertex attributes,
 * binding them to buffer binding points, and specifying their formats.
 * finally, it defines the indices of the vertices that form the two triangles and attaches the index buffer to the VAO.
 */
void GLPbo::setup_quad_vao()
{
	//we'll define a rectangle in normalizeed device coordinates (NDC)
	// coordinates that has one-fourth the area of the window.
	// The NDC coordinates for a window range from [-1, 1] along both
	// both the X- and Y-axes. Therefore, the rectangle's (x, y) position
	// coordinates are in range [-0.5, 0.5]
	// We're using NDC coordinates, because we don't want to specify
	// a "model-to-world-to-view-to-clip" transform to the vertex shader.

	//define the positions of the 4 vertices of a square in the 2D plane
	std::array<glm::vec2, 4> pos_vtx
	{
		glm::vec2(1.f,-1.f), glm::vec2(1.f, 1.f),
		glm::vec2(-1.f,1.f), glm::vec2(-1.f, -1.f)
	};

	//define the texture coord
	std::array<glm::vec2, 4> texcoord_vtx
	{
		glm::vec2(1.0f, 0.0f), glm::vec2(1.0f, 1.0f),
		glm::vec2(0.0f, 1.0f), glm::vec2(0.0f, 0.0f)
	};

	//create a buffer object to store the vertex data
	GLuint vbo_hdl;
	//allocate storage for the buffer object and specify the usage as dynamic
	glCreateBuffers(1, &vbo_hdl); 
	glNamedBufferStorage(vbo_hdl,sizeof(glm::vec2) * pos_vtx.size() + sizeof(glm::vec2)*texcoord_vtx.size(), nullptr, GL_DYNAMIC_STORAGE_BIT);
	//copy the position data to the buffer object
	glNamedBufferSubData(vbo_hdl, 0, sizeof(glm::vec2) * pos_vtx.size(), pos_vtx.data());
	//copy the texture data to the buffer object data
	glNamedBufferSubData(vbo_hdl, sizeof(glm::vec2) * pos_vtx.size() , sizeof(glm::vec2) * texcoord_vtx.size(), texcoord_vtx.data());

	//get the maximum number of vertex attributes supported by the implementation
	GLint max_vtx_attribs;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &max_vtx_attribs);
	//std::cout << "Maximum vertex attributes: " << max_vtx_attribs << '\n';

	GLint max_vtx_binding_buffer;
	glGetIntegerv(GL_MAX_VERTEX_ATTRIB_BINDINGS, &max_vtx_binding_buffer);
	//std::cout << "Maximum vertex buffer bindings: " << max_vtx_binding_buffer << '\n';

	//create a vertex array object to store the vertex attribute state
	glCreateVertexArrays(1, &vaoid);

	//enable vertex attribute 8 and bind it to vertex buffer binding point 3
	glEnableVertexArrayAttrib(vaoid, 0);
	glVertexArrayVertexBuffer(vaoid, 3, vbo_hdl, 0, sizeof(glm::vec2));

	//specify the format of the vertex attribute data for attribute 8
	glVertexArrayAttribFormat(vaoid, 0, 2, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 8
	glVertexArrayAttribBinding(vaoid, 0, 3);

	//enable vertex attribute 10 and bind it to vertex buffer binding point 5
	glEnableVertexArrayAttrib(vaoid, 1);
	glVertexArrayVertexBuffer(vaoid, 5, vbo_hdl, sizeof(glm::vec2) * pos_vtx.size(), sizeof(glm::vec2));

	//specify the format of the vertex attribute data for attribute 10
	glVertexArrayAttribFormat(vaoid, 1, 2, GL_FLOAT, GL_FALSE, 0);

	//specify the vertex buffer binding point for attribute 10
	glVertexArrayAttribBinding(vaoid, 1, 5);

	//define the indices of the vertices that form the two triangles
	std::array<GLushort, 6> idx_vtx
	{
		0, 1, 2,
		2, 3, 0
	};

	GLPbo::elem_cnt = idx_vtx.size();

	//the number of indices in the index array is stored in 'idx_elem_cnt'.
	GLuint ebo_hdl;
	glCreateBuffers(1, &ebo_hdl);

	//generate a buffer object for the index data and store its handle in ebo_hdl.
	glNamedBufferStorage(ebo_hdl, sizeof(GLushort) * GLPbo::elem_cnt,
		reinterpret_cast<GLvoid*>(idx_vtx.data()), GL_DYNAMIC_STORAGE_BIT);

	glVertexArrayElementBuffer(vaoid, ebo_hdl);
	//attach the index buffer to the vertex array .
	glBindVertexArray(0);
}

/**
 * @brief sets up the shader program for rendering a full-screen quad with texture mapping
 * this function compiles the vertex and fragment shaders from the provided shader source code strings.
 * it creates a shader program object, attaches the compiled shaders, and links the program.
 * it also validates the linked program to check for any errors.
 * if any compilation, linking, or validation step fails, an error message is printed and the program exits.
 */
void GLPbo::setup_shdrpgm()
{
	const GLchar* vertexShdr = R"(
    #version 450 core

    layout (location=0) in vec2 iVertexPosition;
    layout (location=1) in vec2 iVertexTexture;

    layout (location=1) out vec2 oTexCoord;

    void main(void){
        gl_Position = vec4(iVertexPosition, 0.0, 1.0);
        oTexCoord = iVertexTexture;
    }
    )";

	const GLchar* fragShdr = R"(
    #version 450 core

    layout (location = 1) in vec2 iTexCoord;
    layout (location = 0) out vec4 oFragColor;
    uniform sampler2D Tex2d;
    
    void main()
	{
        oFragColor = texture(Tex2d,iTexCoord);
    }

    )";

	std::vector<std::pair<GLenum, std::string>> shdr_files;
	shdr_files.emplace_back(std::make_pair(GL_VERTEX_SHADER, vertexShdr));
	shdr_files.emplace_back(std::make_pair(GL_FRAGMENT_SHADER, fragShdr));

	for (auto &shader : shdr_files)
	{
		if (!shdr_pgm.CompileShaderFromString(shader.first, shader.second))
		{
			std::cout << "Unable to compile shader programs from string" << "\n";
			std::cout << shdr_pgm.GetLog() << std::endl;
			std::exit(EXIT_FAILURE);
		}
	}

	if (!shdr_pgm.Link())
	{
		std::cout << "Unable to link shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}

	if (!shdr_pgm.Validate())
	{
		std::cout << "Unable to validate shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}

	//shdr_pgm.Link(shdr_files);
	if (GL_FALSE == shdr_pgm.IsLinked())
	{
		std::cout << "Unable to compile/link/validate shader programs" << "\n";
		std::cout << shdr_pgm.GetLog() << std::endl;
		std::exit(EXIT_FAILURE);
	}


}

/*
 * brief overloaded functions GLPbo::set_clear_color() that set static data member
 * GLPbo::clear_clr with 32-bit RGBA values specified by function parameters. These
 * functions emulate the behavior of GL command glClearColor()
*/
void GLPbo::set_clear_color(GLPbo::Color color)
{
	//set color to the color itself
	clear_clr = color;
}

/*
 * @brief overloaded functions GLPbo::set_clear_color() that set static data member
 * GLPbo::clear_clr with 32-bit RGBA values specified by function parameters. These
 * functions emulate the behavior of GL command glClearColor()  
*/
void GLPbo::set_clear_color(GLubyte r, GLubyte g, GLubyte b, GLubyte a)
{
	//set all color rbg into the respeective rgb
	clear_clr = Color(r, g, b, a);
}

/*
 * @brief  GLPbo::clear_color_buffer() . This function emulates GL command
 * glClear(GL_COLOR_BUFFER_BIT) by using pointer GLPbo::ptr_to_pbo to fill the PBO's data
 * store with RGBA value in GLPbo::clear_clr . Since you'll write millions of bytes, think of how
 * this can be done as efficiently as possible - potential candidates from the standard library
 * include std::fill or std::fill_n or combinations of these fill functions with
 * std::memcpy. 
*/
void GLPbo::clear_color_buffer()
{
	//using pointer GLPbo::ptr_to_pbo to fill the PBO's data using std::fill_n
	std::fill_n(ptr_to_dbo, pixel_cnt, 1.f);
	std::fill_n(ptr_to_pbo, pixel_cnt, clear_clr);
}


/*
 * @brief calculates the inverse transformation of a 3D point from world coordinates to model coordinates.
 * @param modelToWorld The transformation matrix from model space to world space.
 * @param  points The 3D point in world coordinates.
 * @return The inverse transformed point in model coordinates.
*/
glm::vec3 GLPbo::Triangle::inverseWorldCal(glm::mat4 const& modelToWorld, glm::vec3 const& points)
{
	return  glm::inverse(modelToWorld) * glm::vec4{points,1};
}

/*
 * @brief calculates the rotation matrix for a given axis and angle.
 * @param x The x-component of the rotation axis.
 * @param y The y-component of the rotation axis.
 * @param z The z-component of the rotation axis.
 * @param radian The angle of rotation in radians.
 * @return The rotation matrix as a glm::mat4.
*/
glm::mat4 GLPbo::Rotation::rotationCalculation(GLfloat x, GLfloat y, GLfloat z, GLfloat radian)
{
	//identity matrix
	glm::mat4 identityMtx
	{
		CORE10::identityMtx,0.f,0.f,0.f,
		0.f,CORE10::identityMtx,0.f,0.f,
		0.f,0.f,CORE10::identityMtx,0.f,
		0.f,0.f,0.f,CORE10::identityMtx
	};

	//axis formula
	glm::mat4 middleFormula
	{
		x * x, x * y, x * z,0.f,
		x * y, y * y, y * z,0.f,
		x * z, y * z, z * z,0.f,
		0.f,0.f,0.f,1.f
	};

	//axis formula
	glm::mat4 endingFormula
	{
		0.f, z, -y,0.f,
		-z, 0.f, x,0.f,
		y, -x, 0.f,0.f,
		0.f,0.f,0.f,1.f
	};
	//concat evverything into 1
	glm::mat4 finalCalculatedAxisRotation = (cosf(radian) * identityMtx) + ((1.f - cosf(radian)) * middleFormula) + (sinf(radian) * endingFormula);

	//return
	return finalCalculatedAxisRotation;

}

/*
 * @brief calculates the normal vector of a triangle given its three vertices.
 * @param p0 The first vertex of the triangle.
 * @param p1 The second vertex of the triangle.
 * @param p2 The third vertex of the triangle.
 * @return The normal vector of the triangle.
*/
glm::vec3 GLPbo::Triangle::calculateTriangleNormal(glm::vec3 const& p0, glm::vec3 const& p1, glm::vec3 const& p2) 
{
	//calculate the two edge vectors of the triangle
	glm::vec3 v0 = p1 - p0;
	glm::vec3 v1 = p2 - p0;
	//calculate the normal vector by taking the cross product of the two edge vectors
	glm::vec3 normal = glm::cross(v0, v1);
	//normalize the normal vector to ensure unit length
	normal = glm::normalize(normal);

	return normal;
}

/*
 * @brief calculates the faceted shading color for a point light source on a triangle.
 * @param lightPosition The position of the point light source.
 * @param triangleCenter The center point of the triangle.
 * @param normal The normal vector of the triangle.
 * @param intensity The intensity of the light source.
 * @param defuserColor The color of the triangle's defuser.
 * @return The faceted shading color calculated for the triangle.
 * @return The normal vector of the triangle.
*/
glm::vec3 GLPbo::PointLight::calculateLighting(glm::vec3 const& lightPosition,
	glm::vec3 const& triangleCenter, glm::vec3 const& normal,
	glm::vec3 const& intensity, 
	glm::vec3 const& defuserColor)
{
	//calculate the direction from the triangle center to the light source
	glm::vec3 directionToLight = glm::normalize(lightPosition - triangleCenter);

	//calculate the incoming light 
	float incomingLight = glm::dot(normal, directionToLight);
	//clamp the incoming light value between 0 and 1
	glm::vec3 finalIncomingLight = glm::max(0.f, incomingLight) * intensity;
	//calculate the outgoing light by multiplying the defuser color and the final incoming light
	glm::vec3 outgoingLight = defuserColor * finalIncomingLight;

	return outgoingLight;
}

/*
 * @brief retrieves the texel color at the specified coordinates from the texture.
 * @param x The x-coordinate of the texel.
 * @param y The y-coordinate of the texel.
 * @return The texel color as a glm::vec3 vector.
*/
glm::vec3 GLPbo::TextureObj::getTexelColor(GLint x, GLint y)
{
	//calculate the texel index based on the coordinates and texture properties
	int texelIndex = (y * textureID.x + x) * textureID.bytes;
	//check if the texel color buffer is initialized
	if (!ptr_texelColor)
	{
		ptr_texelColor = new GLubyte[3];
	}
	//check if the texel index is within the valid range
	if (texelIndex < fileSize)
	{
		//retrieve the red, green, and blue components of the texel
		unsigned char red = ptr_texels[texelIndex];
		unsigned char green = ptr_texels[texelIndex + 1];
		unsigned char blue = ptr_texels[texelIndex + 2];
		//store the texel color components in the texel color buffer
		ptr_texelColor[0] = red;
		ptr_texelColor[1] = green;
		ptr_texelColor[2] = blue;
		//return the texel color as a glm::vec3 vector
		return glm::vec3(static_cast<GLubyte>(red), static_cast<GLubyte>(green), static_cast<GLubyte>(blue));
	}

	//retrieve color component of the first texel (default color)
	unsigned char red = ptr_texels[0];
	unsigned char green = ptr_texels[0];
	unsigned char blue = ptr_texels[0];

	ptr_texelColor[0] = red;
	ptr_texelColor[1] = green;
	ptr_texelColor[2] = blue;
	//return the default texel color as a glm::vec3 vector
	return glm::vec3(static_cast<GLubyte>(red), static_cast<GLubyte>(green), static_cast<GLubyte>(blue));
}

/**
 * @brief Cleans up the resources used by GLPbo.
 * this function deletes the vertex array object, pixel buffer object, and texture object.
 * it sets the corresponding handles to 0 to indicate that the resources are no longer valid.
 */
void GLPbo::cleanup()
{
	//delete the vertex array data
	glDeleteVertexArrays(1, &vaoid);
	vaoid = 0;
	//delete the pixel buffer data
	glDeleteBuffers(1, &pboid);
	pboid = 0;
	//delete the texture data
	glDeleteTextures(1, &texid);
	texid = 0;

	delete[] ptr_texels;
	ptr_texels = nullptr;

	delete[] ptr_to_dbo;
	ptr_to_dbo = nullptr;

	delete[] ptr_texelColor;
	ptr_texelColor = nullptr;
}
